<?php
/**
 * Copyright © PZ, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace PZ\VCA\Model;

/**
 * Appointment Model Class
 */
class Appointment extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface, \PZ\VCA\Api\Data\AppointmentInterface
{
    final public const NOROUTE_ENTITY_ID = 'no-route';

    final public const CACHE_TAG = 'pz_vca_appointment';

    protected $_cacheTag = 'pz_vca_appointment';

    protected $_eventPrefix = 'pz_vca_appointment';

    /**
     * Set resource model
     */
    public function _construct()
    {
        $this->_init(\PZ\VCA\Model\ResourceModel\Appointment::class);
    }

    /**
     * Load No-Route Indexer.
     *
     * @return $this
     */
    public function noRouteReasons()
    {
        return $this->load(self::NOROUTE_ENTITY_ID, $this->getIdFieldName());
    }

    /**
     * Get identities.
     *
     * @return []
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG.'_'.$this->getId()];
    }

    /**
     * Set EntityId
     *
     * @param int $entityId
     * @return \PZ\VCA\Model\AppointmentInterface
     */
    public function setEntityId($entityId)
    {
        return $this->setData(self::ENTITY_ID, $entityId);
    }

    /**
     * Get EntityId
     *
     * @return int
     */
    public function getEntityId()
    {
        return parent::getData(self::ENTITY_ID);
    }

    /**
     * Set OrderId
     *
     * @param int $orderId
     * @return \PZ\VCA\Model\AppointmentInterface
     */
    public function setOrderId($orderId)
    {
        return $this->setData(self::ORDER_ID, $orderId);
    }

    /**
     * Get OrderId
     *
     * @return int
     */
    public function getOrderId()
    {
        return parent::getData(self::ORDER_ID);
    }

    /**
     * Set code
     *
     * @param string $code
     * @return \PZ\VCA\Model\AppointmentInterface
     */
    public function setCode($code)
    {
        return $this->setData(self::CODE, $code);
    }

    /**
     * Get code
     *
     * @return \PZ\VCA\Model\AppointmentInterface
     */
    public function getCode()
    {
        return $this->getData(self::CODE);
    }

    /**
     * Set CustomerEmail
     *
     * @param string $customerEmail
     * @return \PZ\VCA\Model\AppointmentInterface
     */
    public function setCustomerEmail($customerEmail)
    {
        return $this->setData(self::CUSTOMER_EMAIL, $customerEmail);
    }

    /**
     * Get CustomerEmail
     *
     * @return string
     */
    public function getCustomerEmail()
    {
        return parent::getData(self::CUSTOMER_EMAIL);
    }

    /**
     * Set IsExpited
     *
     * @param int $isExpited
     * @return \PZ\VCA\Model\AppointmentInterface
     */
    public function setIsExpited($isExpited)
    {
        return $this->setData(self::IS_EXPITED, $isExpited);
    }

    /**
     * Get IsExpited
     *
     * @return int
     */
    public function getIsExpited()
    {
        return parent::getData(self::IS_EXPITED);
    }

    /**
     * Set Duration
     *
     * @param int $duration
     * @return \PZ\VCA\Model\AppointmentInterface
     */
    public function setDuration($duration)
    {
        return $this->setData(self::DURATION, $duration);
    }

    /**
     * Get Duration
     *
     * @return int
     */
    public function getDuration()
    {
        return parent::getData(self::DURATION);
    }

    /**
     * Set ScheduledAt
     *
     * @param string $scheduledAt
     * @return \PZ\VCA\Model\AppointmentInterface
     */
    public function setScheduledAt($scheduledAt)
    {
        return $this->setData(self::SCHEDULED_AT, $scheduledAt);
    }

    /**
     * Get ScheduledAt
     *
     * @return string
     */
    public function getScheduledAt()
    {
        return parent::getData(self::SCHEDULED_AT);
    }

    /**
     * Set CreatedAt
     *
     * @param string $createdAt
     * @return \PZ\VCA\Model\AppointmentInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get CreatedAt
     *
     * @return string
     */
    public function getCreatedAt()
    {
        return parent::getData(self::CREATED_AT);
    }
}

