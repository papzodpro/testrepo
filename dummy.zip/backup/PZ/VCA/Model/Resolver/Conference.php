<?php

declare(strict_types=1);

namespace PZ\VCA\Model\Resolver;

use Magento\Authorization\Model\UserContextInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Test\TestGraphQl\Model\Resolver\Customer\CustomerDataProvider;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlAuthorizationException;
use Magento\Framework\GraphQl\Exception\GraphQlNoSuchEntityException;
use Magento\Framework\GraphQl\Query\Resolver\ContextInterface;
use Magento\Framework\GraphQl\Query\Resolver\Value;
use Magento\Framework\GraphQl\Query\Resolver\ValueFactory;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use PZ\VCA\Model\AppointmentFactory;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Api\Data\CustomerInterface;
use Magento\Framework\Webapi\ServiceOutputProcessor;
use Magento\Framework\Api\ExtensibleDataObjectConverter;

/**
 * Customers field resolver, used for GraphQL request processing.
 */
class Conference implements ResolverInterface
{
    /**
    * @var ValueFactory
    */
    private $valueFactory;

    /**
    * @var AppointmentFactory
    */
    private $appointmentFactory;

    private $customerRepository;

    /**
    * @var ServiceOutputProcessor
    */
    private $serviceOutputProcessor;

    /**
    * @var ExtensibleDataObjectConverter
    */
    private $dataObjectConverter;

    /**
    * @var \Psr\Log\LoggerInterface
    */
    private $logger;

    /**
     *
     * @param ValueFactory $valueFactory
     * @param AppointmentFactory $appointmentFactory
     * @param ServiceOutputProcessor $serviceOutputProcessor
     * @param ExtensibleDataObjectConverter $dataObjectConverter
     */
    public function __construct(
        ValueFactory $valueFactory,
        AppointmentFactory $appointmentFactory,
        ServiceOutputProcessor $serviceOutputProcessor,
        ExtensibleDataObjectConverter $dataObjectConverter,
        CustomerRepositoryInterface $customerRepository,
        \Psr\Log\LoggerInterface $logger
    ) {
        $this->valueFactory = $valueFactory;
        $this->appointmentFactory = $appointmentFactory;
        $this->serviceOutputProcessor = $serviceOutputProcessor;
        $this->dataObjectConverter = $dataObjectConverter;
        $this->customerRepository = $customerRepository;
        $this->logger = $logger;
    }

    /**
    * {@inheritdoc}
    */
    public function resolve(
        Field $field,
        $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) : Value {
        // if (isset($args["code"]) && $args["code"]) {
        //     throw new GraphQlAuthorizationException(
        //         __(
        //             'Invalid conference code',
        //         )
        //     );
        // }

        try {
            $data = [
                "host_email" => "host@gmail.com",
                "customer_email" => "user_2@example.com",
                "conference_date" => "19-04-2014",
                "is_expired" => false,
                "code" => "uhhghg"
            ];
            $result = function () use ($data) {
                return !empty($data) ? $data : [];
            };
            return $this->valueFactory->create($result);
        } catch (NoSuchEntityException $exception) {
            throw new GraphQlNoSuchEntityException(__($exception->getMessage()));
        } catch (LocalizedException $exception) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()));
        }
    }
}