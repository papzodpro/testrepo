<?php
/**
 * Copyright © PZ, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace PZ\VCA\Model;
use Magento\Framework\Api\Search\SearchResultFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use PZ\VCA\Api\AppointmentRepositoryInterface;

/**
 * AppointmentRepository Repo Class
 */
class AppointmentRepository implements AppointmentRepositoryInterface
{
    protected $modelFactory;

    protected $collectionFactory;

    protected $collectionProcessor;

    protected $searchResultsFactory;

    /**
     *
     * @param \PZ\VCA\Model\AppointmentFactory $modelFactory
     * @param \PZ\VCA\Model\ResourceModel\Appointment\CollectionFactory $collectionFactory
     * @param CollectionProcessorInterface|null $collectionProcessor
     * @param SearchResultsFacory $searchResultsFactory
     */
    public function __construct(
        \PZ\VCA\Model\AppointmentFactory $modelFactory,
        \PZ\VCA\Model\ResourceModel\Appointment\CollectionFactory $collectionFactory,
        CollectionProcessorInterface $collectionProcessor = null,
        SearchResultFactory $searchResultsFactory
    ) {
        $this->modelFactory = $modelFactory;
        $this->collectionFactory = $collectionFactory;
        $this->collectionProcessor = $collectionProcessor;
        $this->searchResultsFactory = $searchResultsFactory;
    }

    /**
     * Get by id
     *
     * @param int $id
     * @return \PZ\VCA\Model\Appointment
     */
    public function getById($id)
    {
        $model = $this->modelFactory->create()->load($id);
        if (!$model->getId()) {
            throw new \Magento\Framework\Exception\NoSuchEntityException(
                __('The data with the "%1" ID doesn\'t exist.', $id)
            );
        }
        return $model;
    }

    /**
     * Get by code.
     *
     * @param string $code
     * @return \PZ\VCA\Model\Appointment
     */
    public function getByCode($code)
    {
        $model = $this->modelFactory->create()->load($code, "code");
        if (!$model->getId()) {
            throw new \Magento\Framework\Exception\NoSuchEntityException(
                __('The data with the "%1" ID doesn\'t exist.', $id)
            );
        }
        return $model;
    }

    /**
     * Save
     *
     * @param \PZ\VCA\Model\Appointment $subject
     * @return \PZ\VCA\Model\Appointment
     */
    public function save(\PZ\VCA\Model\Appointment $subject)
    {
        try {
            $subject->save();
        } catch (\Exception $exception) {
             throw new \Magento\Framework\Exception\CouldNotSaveException(__($exception->getMessage()));
        }
        return $subject;
    }

    /**
     * Get list
     *
     * @param Magento\Framework\Api\SearchCriteriaInterface $creteria
     * @return Magento\Framework\Api\SearchResults
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $creteria)
    {
        $collection = $this->collectionFactory->create();
        $this->collectionProcessor->process($criteria, $collection);

        /** @var Data\BlockSearchResultsInterface $searchResults */
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        $searchResults->setItems($collection->getItems());
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * Delete
     *
     * @param \PZ\VCA\Model\Appointment $subject
     * @return boolean
     */
    public function delete(\PZ\VCA\Model\Appointment $subject)
    {
        try {
            $subject->delete();
        } catch (\Exception $exception) {
            throw new \Magento\Framework\Exception\CouldNotDeleteException(__($exception->getMessage()));
        }
        return true;
    }

    /**
     * Delete by id
     *
     * @param int $id
     * @return boolean
     */
    public function deleteById($id)
    {
        return $this->delete($this->getById($id));
    }
}

