<?php
/**
 * Copyright © PZ, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */


namespace PZ\VCA\Model\ResourceModel\Appointment;

/**
 * Appointment Collection Class
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'entity_id';

    /**
     * Initialize resource model
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init(
            \PZ\VCA\Model\Appointment::class,
            \PZ\VCA\Model\ResourceModel\Appointment::class
        );
        $this->_map['fields']['entity_id'] = 'main_table.entity_id';
    }
}

