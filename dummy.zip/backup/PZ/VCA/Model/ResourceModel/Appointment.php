<?php
/**
 * Copyright © PZ, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace PZ\VCA\Model\ResourceModel;

/**
 * Appointment RosourceModel Class
 */
class Appointment extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init("pz_appointment_schedule", "entity_id");
    }
}

