<?php
/**
 * Copyright © PZ, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace PZ\VCA\Model;

use Magento\Framework\Math\Random;

class AppointmentManager
{
    public const CODE_LENGTH = 8;

    private $appointmentRepository;

    private $appointmentFactory;

    private $random;
    
    public function __construct(
        AppointmentRepository $appointmentRepository,
        AppointmentFactory $appointmentFactory,
        Random $random
    ) {
        $this->appointmentRepository = $appointmentRepository;
        $this->appointmentFactory = $appointmentFactory;
        $this->random = $random;
    }

    /**
     * Create Meeting.
     *
     * @param array $data
     * @return void
     */
    public function createMeeting(array $data)
    {
        $videoCode = $this->generateVideoCode();

        if (!$this->checkIfVideoCodeExists($videoCode)) {
            $data["code"] = $videoCode;
            $appointment = $this->appointmentFactory->create();
            $appointment->setData($data);
            return $this->appointmentRepository->save($appointment);
        }
    }

    /**
     * Check if code already exists.
     *
     * @param string $code
     * @return boolean
     */
    public function checkIfVideoCodeExists(string $code) : bool|Appointment
    {
        try {
            return $this->appointmentRepository->getByCode($code);
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Generate video code.
     *
     * @return string
     */
    public function generateVideoCode() : string
    {
        return $this->random->getRandomString(self::CODE_LENGTH, null);
    }
}