define([
	'jquery',
	'uiComponent',
	'ko',
	'PZ_VCA/js/socket-io',
	"Magento_Ui/js/modal/confirm"
], function (
	$,
	Component,
	ko,
	io,
	confirmation
) {
    'use strict';
    return Component.extend({
        defaults: {
            template: 'PZ_VCA/conference',
            title: "Video Conference",
			localVideoComponent: "",
			remoteVideoComponent: "",
			localStream: null,
			customerName: "John Doe",
			hostName: "papzod",
			socket: null,
			rtcPeerConnection: null,
			isRoomCreator: null,
			iceServers: {
				iceServers: [
				  { urls: 'stun:stun.l.google.com:19302' },
				  { urls: 'stun:stun1.l.google.com:19302' },
				  { urls: 'stun:stun2.l.google.com:19302' },
				  { urls: 'stun:stun3.l.google.com:19302' },
				  { urls: 'stun:stun4.l.google.com:19302' },
				],
			}
        },
        initialize: function () {
            this._super();  
			this.socket = io("http://localhost:3001");
			this.isHost = parseInt(this.isHost);
			console.log(this.isHost?true:false, this.room);
			this.isRoomCreator = this.isHost?true:false;
			if (this.isRoomCreator) {
				this.customerName = "John Doe";
				this.hostName = "Papzod";
			} else {
				this.customerName = "Papzod";
				this.hostName = "John Doe";
			}
			let that = this;

			this.socket.on("room_created", async function (roomId) {

				await that.setLocalStream();
				console.log(roomId, "room joined by host");
			});

			this.socket.on('room_joined', async () => {
				console.log('Socket event callback: room_joined');
			  
				await that.setLocalStream();
				this.socket.emit('start_call', that.room);
			});

			this.socket.on('full_room', () => {
				console.log('Socket event callback: full_room');
				
				alert('The room is full, please try another one');
			});

			this.socket.on('start_call', async () => {
				console.log('Socket event callback: start_call')
				
				if (that.isRoomCreator) {
					that.rtcPeerConnection = new RTCPeerConnection(that.iceServers)
					that.addLocalTracks(that.rtcPeerConnection)
					that.rtcPeerConnection.ontrack = that.setRemoteStream.bind(that)
					that.rtcPeerConnection.onicecandidate = that.sendIceCandidate.bind(that)
					await that.createOffer(that.rtcPeerConnection)
				}
			});
			
			this.socket.on('webrtc_offer', async (event) => {
				console.log('Socket event callback: webrtc_offer')
				
				if (!that.isRoomCreator) {
					that.rtcPeerConnection = new RTCPeerConnection(that.iceServers)
					that.addLocalTracks(that.rtcPeerConnection)
					that.rtcPeerConnection.ontrack = that.setRemoteStream.bind(that)
					that.rtcPeerConnection.onicecandidate = that.sendIceCandidate.bind(that)
					that.rtcPeerConnection.setRemoteDescription(new RTCSessionDescription(event))
					await that.createAnswer(that.rtcPeerConnection)
				}
			})
			
			this.socket.on('webrtc_answer', (event) => {
				console.log('Socket event callback: webrtc_answer')
				
				that.rtcPeerConnection.setRemoteDescription(new RTCSessionDescription(event))
			})
			
			this.socket.on('webrtc_ice_candidate', (event) => {
				console.log('Socket event callback: webrtc_ice_candidate')
				
				// ICE candidate configuration.
				const candidate = new RTCIceCandidate({
					sdpMLineIndex: event.label,
					candidate: event.candidate,
				})
				that.rtcPeerConnection.addIceCandidate(candidate)
			})
        },

        setLocalStream: async function () {
            this.localVideoComponent = document.getElementById("current-stream");
			
            const mediaConstraints = {
                audio: true,
                video: { width: 1280, height: 720 }
            };
            try {
              this.localStream = await navigator.mediaDevices.getUserMedia(mediaConstraints)
              this.localVideoComponent.srcObject = this.localStream;
            } catch (error) {
              console.error('Could not get user media', error)
            }
		},

		setRemoteStream: async function (event) {
			this.remoteVideoComponent = document.getElementById("remote-stream");
			this.remoteVideoComponent.srcObject = event.streams[0];
			this.remoteStream = event.stream;
			$(".video-item").show();
		},

		addLocalTracks: function(rtcPeerConnection) {
			this.localStream.getTracks().forEach((track) => {
			  rtcPeerConnection.addTrack(track, this.localStream)
			})
		},

		sendIceCandidate: function (event) {
			if (event.candidate) {
				this.socket.emit('webrtc_ice_candidate', {
					roomId:this.room,
					label: event.candidate.sdpMLineIndex,
					candidate: event.candidate.candidate,
				});
			}
		},

		createOffer: async function (rtcPeerConnection) {
			try {
			  const sessionDescription = await rtcPeerConnection.createOffer()
			  rtcPeerConnection.setLocalDescription(sessionDescription)
			  
			  this.socket.emit('webrtc_offer', {
				type: 'webrtc_offer',
				sdp: sessionDescription,
				roomId:this.room,
			  })
			} catch (error) {
			  console.error(error)
			}
		},

		createAnswer: async function (rtcPeerConnection) {
			try {
			  const sessionDescription = await rtcPeerConnection.createAnswer()
			  rtcPeerConnection.setLocalDescription(sessionDescription)
			  
			  this.socket.emit('webrtc_answer', {
				type: 'webrtc_answer',
				sdp: sessionDescription,
				roomId: this.room,
			  })
			} catch (error) {
			  console.error(error)
			}
		},

		/**
		 * Mute video
		 * @private
		 */
		_muteVideo: function (data, event) {
			$(event.target).toggleClass( "off" );
			data.localStream.getVideoTracks().forEach(track => track.enabled = !track.enabled);
		},

		/**
		 * Mute audio
		 * @private
		 */
		_muteAudio: function (data, event) {
			$(event.target).toggleClass( "off" );
			data.localStream.getAudioTracks().forEach(track => track.enabled = !track.enabled);
		},

		_endVideo: function(data, event) {
			$(event.target).toggleClass( "off" );
			confirmation({
                title: 'Confirm',
                content: 'Are you sure you want to exit the call?',
                actions: {

                    confirm: function () {
                        location.href = "http://localhost/";
                    },

                    cancel: function () {
                        return false;
                    }
                }
            });
			
		},

		joinConference: function () {
			this.socket.emit("join", this.room);
			$(".join-container").hide();
		}
    });
}
);