<?php
/**
 * Copyright © PZ, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace PZ\VCA\Api;

/**
 * AppointmentRepository Repository Interface
 */
interface AppointmentRepositoryInterface
{
    /**
     * Get by id
     *
     * @param int $id
     * @return \PZ\VCA\Model\Appointment
     */
    public function getById($id);
    /**
     * Save
     *
     * @param \PZ\VCA\Model\Appointment $subject
     * @return \PZ\VCA\Model\Appointment
     */
    public function save(\PZ\VCA\Model\Appointment $subject);
    /**
     * Get list
     *
     * @param Magento\Framework\Api\SearchCriteriaInterface $creteria
     * @return Magento\Framework\Api\SearchResults
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $creteria);
    /**
     * Delete
     *
     * @param \PZ\VCA\Model\Appointment $subject
     * @return boolean
     */
    public function delete(\PZ\VCA\Model\Appointment $subject);
    /**
     * Delete by id
     *
     * @param int $id
     * @return boolean
     */
    public function deleteById($id);
}

