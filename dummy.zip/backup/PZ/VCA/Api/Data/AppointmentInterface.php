<?php
/**
 * Copyright © PZ, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace PZ\VCA\Api\Data;

/**
 * Appointment Model Interface
 */
interface AppointmentInterface
{
    public const ENTITY_ID = 'entity_id';

    public const ORDER_ID = 'order_id';

    public const CUSTOMER_EMAIL = 'customer_email';

    public const HOST_EMAIL = 'host_email';

    public const CUSTOMER_NAME = 'customer_name';

    public const CODE = 'code';

    public const HOST_NAME = 'host_name';

    public const IS_EXPITED = 'is_expited';

    public const DURATION = 'duration';

    public const SCHEDULED_AT = 'scheduled_at';

    public const CREATED_AT = 'created_at';

    /**
     * Set EntityId
     *
     * @param int $entityId
     * @return \PZ\VCA\Api\Data\AppointmentInterface
     */
    public function setEntityId($entityId);
    /**
     * Get EntityId
     *
     * @return int
     */
    public function getEntityId();
    /**
     * Set OrderId
     *
     * @param int $orderId
     * @return \PZ\VCA\Api\Data\AppointmentInterface
     */
    public function setOrderId($orderId);
    /**
     * Get OrderId
     *
     * @return int
     */
    public function getOrderId();
    /**
     * Set CustomerEmail
     *
     * @param string $customerEmail
     * @return \PZ\VCA\Api\Data\AppointmentInterface
     */
    public function setCustomerEmail($customerEmail);

    /**
     * Get code
     *
     * @return string
     */
    public function getCode();

    /**
     * Set code
     *
     * @param string $code
     * @return string
     */
    public function setCode($code);

    /**
     * Get CustomerEmail
     *
     * @return string
     */
    public function getCustomerEmail();
    /**
     * Set IsExpited
     *
     * @param int $isExpited
     * @return \PZ\VCA\Api\Data\AppointmentInterface
     */
    public function setIsExpited($isExpited);
    /**
     * Get IsExpited
     *
     * @return int
     */
    public function getIsExpited();
    /**
     * Set Duration
     *
     * @param int $duration
     * @return \PZ\VCA\Api\Data\AppointmentInterface
     */
    public function setDuration($duration);
    /**
     * Get Duration
     *
     * @return int
     */
    public function getDuration();
    /**
     * Set ScheduledAt
     *
     * @param string $scheduledAt
     * @return \PZ\VCA\Api\Data\AppointmentInterface
     */
    public function setScheduledAt($scheduledAt);
    /**
     * Get ScheduledAt
     *
     * @return string
     */
    public function getScheduledAt();
    /**
     * Set CreatedAt
     *
     * @param string $createdAt
     * @return \PZ\VCA\Api\Data\AppointmentInterface
     */
    public function setCreatedAt($createdAt);
    /**
     * Get CreatedAt
     *
     * @return string
     */
    public function getCreatedAt();
}

