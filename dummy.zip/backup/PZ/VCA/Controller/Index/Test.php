<?php
namespace PZ\VCA\Controller\Index;

class Test extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory)
	{
		$this->_pageFactory = $pageFactory;
		return parent::__construct($context);
	}

	public function execute()
	{
		$manager = $this->_objectManager->create(\PZ\VCA\Model\AppointmentManager::class);
        $data = [
            "order_id" => 1,
            "customer_email" => "customer@gmail.com",
            "customer_name" => "Customer",
            "duration" => 60,
            "scheduled_at" => "2024-05-01 22:35:00",
            "host_email" => "host@gmail.com",
            "host_name" => "HOST"

        ];
        $appointment = $manager->createMeeting($data);
        echo "<pre>"; print_r($appointment->getData());die;
	}
}