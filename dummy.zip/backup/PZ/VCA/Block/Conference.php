<?php
/**
 * Webkul Software.
 *
 * @category   Webkul
 * @package    PZ_VCA
 * @author     Webkul
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace PZ\VCA\Block;

use Magento\Framework\View\Element\Template\Context;

class Conference extends \Magento\Framework\View\Element\Template
{
    /**
     * Construct function
     *
     * @param Context $context
     * @param array $data
     */
    public function __construct(
        Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);
    }

    public function getHelloMessage()
    {
        return 'Hello from Conference block';
    }
}
