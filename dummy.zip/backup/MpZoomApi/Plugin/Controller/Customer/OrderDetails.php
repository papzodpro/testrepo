<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoomApi
 * @author    Webkul
 * @copyright Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpZoomApi\Plugin\Controller\Customer;

use Magento\Framework\Controller\ResultFactory;

class OrderDetails
{

    /**
     * @var \Magento\Store\Model\Store
     */
    public $store;
    /**
     * @var \Magento\Catalog\Model\Product
     */
    public $product;
    public $_helper;
    public $_request;
    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    public $_jsonHelper;
    public $order;
    public $meetingInfo;
    public $_resultFactory;
    /**
     * @var \Magento\Customer\Model\Session
     */
    public $_customerSession;
    public function __construct(
        ResultFactory $resultFactory,
        \Webkul\MobikulCore\Helper\Data $helper,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Magento\Sales\Model\Order $order,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Catalog\Model\Product $product,
        \Webkul\MpZoom\ViewModel\MeetingInfo $meetingInfo,
        \Magento\Store\Model\Store $store
    ) {
        $this->store            = $store;
        $this->product          = $product;
        $this->_helper          = $helper;
        $this->_request         = $request;
        $this->_jsonHelper      = $jsonHelper;
        $this->order            = $order;
        $this->meetingInfo            = $meetingInfo;
        $this->_resultFactory   = $resultFactory;
        $this->_customerSession = $customerSession;
    }

    public function afterExecute(\Webkul\MobikulApi\Controller\Customer\OrderDetails $subject, $response)
    {
        if ($response->getRawData()) {
            $authKey      = $this->_request->getHeader("authKey");
            $authData     = $this->_helper->isAuthorized($authKey);
            $resultJson   = $this->_resultFactory->create(ResultFactory::TYPE_JSON);
            $wholeData    = $this->_request->getParams();
            $meetingInfoData = [];
            // $currency     = $wholeData["currency"] ?? 'USD';
            $responseData = json_decode($response->getRawData(), true);
            
            if ($authData["code"] == 1) {
                $incrementId = $wholeData['incrementId'] ?? 0;
                $order   = $this->order->loadByIncrementId($incrementId);
                foreach ($order->getAllItems() as $item) {
                    if ($item->getProductType()=='booking' && $item->getQtyInvoiced() >= 0) {
                        $meetingData = $this->meetingInfo->getMeetingInfo($item->getItemId(), $order->getId());
                        if ($meetingData->getData()) {
                            $meetingInfo = json_decode($meetingData->getInfo(), true);
                            $endTime = $this->meetingInfo->getMeetingEndTime($meetingInfo, $item->getProductId());
                            $data = [
                                'product_id' => $item->getProductId(),
                                'item_id' => $item->getItemId(),
                                'meeting_end_time' => $endTime,
                                'join_url' => $this->meetingInfo->getJoiningUrl($order->getId(), $item->getItemId()),
                                'meeting_info' => json_decode($meetingData->getInfo())
                            ];
                            array_push($meetingInfoData, $data);
                        }
                        
                    }
                }
                if ($meetingInfoData) {
                    $responseData['meeting_data'] = $meetingInfoData;
                }
                $resultJson->setData($responseData);
                return $resultJson;
            }
            $resultJson->setData($responseData);
            return $resultJson;
        }
        return $response;
    }
}