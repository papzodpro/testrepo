<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoomApi
 * @author    Webkul
 * @copyright Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpZoomApi\Plugin\Controller\Marketplace;

use Magento\Framework\Controller\ResultFactory;

class ViewOrder
{
    /**
     * @var \Magento\Store\Model\Store
     */
    public $store;
    public $booking;
    /**
     * @var \Magento\Catalog\Model\Product
     */
    public $product;
    public $_helper;
    public $_request;
    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    public $_jsonHelper;
    public $order;
    public $meetingInfo;
    public $_resultFactory;
    /**
     * @var \Webkul\MpAdvancedBookingSystem\Helper\Data
     */
    public $bookingHelper;
    /**
     * @var \Magento\Customer\Model\Session
     */
    public $_customerSession;
    public $marketplaceOrderhelper;
    /**
     * @var \Webkul\Marketplace\Helper\Data
     */
    public $marketplaceDatahelper;
    /**
     * __construct function
     *
     * @param ResultFactory $resultFactory
     * @param \Webkul\MobikulCore\Helper\Data $helper
     * @param \Magento\Framework\App\Request\Http $request
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     * @param \Magento\Sales\Model\Order $order
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Catalog\Model\Product $product
     * @param \Webkul\MpZoom\ViewModel\MeetingInfo $meetingInfo
     * @param \Magento\Store\Model\Store $store
     * @param \Webkul\CustomSlotProduct\Block\Product\Booking $booking
     * @param \Webkul\Marketplace\Helper\Orders $marketplaceOrderhelper
     */
    public function __construct(
        ResultFactory $resultFactory,
        \Webkul\MobikulCore\Helper\Data $helper,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Magento\Sales\Model\Order $order,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Catalog\Model\Product $product,
        \Webkul\MpZoom\ViewModel\MeetingInfo $meetingInfo,
        \Magento\Store\Model\Store $store,
        \Webkul\CustomSlotProduct\Block\Product\Booking $booking,
        \Webkul\Marketplace\Helper\Orders $marketplaceOrderhelper,
        \Webkul\Marketplace\Helper\Data $marketplaceDatahelper,
        \Webkul\MpAdvancedBookingSystem\Helper\Data $bookingHelper
    ) {
        $this->store            = $store;
        $this->booking          = $booking;
        $this->product          = $product;
        $this->_helper          = $helper;
        $this->_request         = $request;
        $this->_jsonHelper      = $jsonHelper;
        $this->order            = $order;
        $this->meetingInfo      = $meetingInfo;
        $this->_resultFactory   = $resultFactory;
        $this->bookingHelper    = $bookingHelper;
        $this->_customerSession = $customerSession;
        $this->marketplaceOrderhelper = $marketplaceOrderhelper;
        $this->marketplaceDatahelper = $marketplaceDatahelper;
    }

    /**
     * After ViewOrder Execute
     *
     * @param \Webkul\MobikulMp\Controller\Marketplace\ViewOrder $subject
     * @param array $response
     * @return array
     */
    public function afterExecute(\Webkul\MobikulMp\Controller\Marketplace\ViewOrder $subject, $response)
    {
        if ($response->getRawData()) {
            $authKey      = $this->_request->getHeader("authKey");
            $authData     = $this->_helper->isAuthorized($authKey);
            $resultJson   = $this->_resultFactory->create(ResultFactory::TYPE_JSON);
            $wholeData    = $this->_request->getParams();
            $meetingInfoData = [];
            // $currency     = $wholeData["currency"] ?? 'USD';
            $responseData = json_decode($response->getRawData(), true);
            if ($authData["code"] == 1 && $responseData['success']) {
                $incrementId = $wholeData['incrementId'] ?? 0;
                $order   = $this->order->loadByIncrementId($incrementId);
                $orderId = $order->getId();
                foreach ($order->getAllItems() as $item) {
                    if ($item->getProductType()=='booking' && $item->getQtyInvoiced() >= 0) {
                        $meetingData = $this->meetingInfo->getMeetingInfo($item->getItemId(), $order->getId());
                        if ($meetingData->getData()) {
                            $meetingInfo = json_decode($meetingData->getInfo(), true);
                            $endTime = $this->meetingInfo->getMeetingEndTime($meetingInfo, $item->getProductId());
                            $data = [
                                'product_id' => $item->getProductId(),
                                'item_id' => $item->getItemId(),
                                'host_url' => $this->meetingInfo->getHostUrl($order->getId(), $item->getItemId()),
                                'join_url' => $this->meetingInfo->getJoiningUrl($order->getId(), $item->getItemId()),
                                'meeting_end_time' => $endTime,
                                'meeting_info' => json_decode($meetingData->getInfo())
                            ];
                            array_push($meetingInfoData, $data);
                        }
                        $slot = $this->booking->getBookedProductSlot($orderId, $item->getProductId());
                        if ($slot->getAssignedSlot() != "") {
                            foreach ($responseData['orderData']['itemList'] as $key => $items) {
                                if ($items['productId'] == $item->getProductId()) {
                                    $items['assign_slot_visiblity'] = false;
                                    $responseData['orderData']['itemList'][$key] = $items;
                                }
                            }
                        } else {
                            foreach ($responseData['orderData']['itemList'] as $key => $items) {
                                if ($items['productId'] == $item->getProductId()) {
                                    $items['assign_slot_visiblity'] = true;
                                    $responseData['orderData']['itemList'][$key] = $items;
                                }
                            }
                        }
                    }
                }
                if ($meetingInfoData) {
                    $responseData['meeting_data'] = $meetingInfoData;
                }
                $status   = $order->getStatus();
                $tracking = $this->marketplaceOrderhelper->getOrderinfo($orderId);
                if (!is_array($tracking) && $tracking->getIsCanceled()) {
                    $status = "Canceled";
                }
                $responseData['statusColorCode'] = $this->getOrderStatusColor($status);
                $resultJson->setData($responseData);
                return $resultJson;
            }
            $resultJson->setData($responseData);
            return $resultJson;
        }
        return $response;
    }

    /**
     * GetOrderStatusColor function
     *
     * @param [String] $status
     * @return String
     */
    public function getOrderStatusColor($status)
    {
        $status = strtolower($status);
        if ($status == 'new' ||
            $status == 'pending payment' ||
            $status == 'pending'
        ) {
            return '#ffbc00';
        } elseif ($status == 'processing') {
            return '#007EFF';
        } elseif ($status == 'complete') {
            return '#19A709';
        } elseif ($status == 'canceled' ||
            $status == 'closed' ||
            $status == 'fraud' ||
            $status == 'payment review'
        ) {
            return '#ff3b00';
        } else {
            return '#ffbc00';
        }
    }
}
