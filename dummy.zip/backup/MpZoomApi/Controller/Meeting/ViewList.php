<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoomApi
 * @author    Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpZoomApi\Controller\Meeting;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class ViewList extends \Webkul\MobikulApi\Controller\ApiController
{
    /**
     * @var \Webkul\MpZoom\Helper\Data
     */
    public $zoomHelper;
    public $order;
    /**
     * @var \Webkul\MpZoom\ViewModel\MeetingInfo
     */
    public $meetingInfo;
    public $customerSession;
    public $emulate;
    public $meetingInfoRepo;
    /**
     * @var PageFactory
     */
    protected $_resultPageFactory;

    /**
     * initialization
     *
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        \Webkul\MobikulCore\Helper\Data $helper,
        \Webkul\MpZoom\Helper\Data $zoomHelper,
        \Magento\Sales\Model\Order $order,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Webkul\MpZoom\ViewModel\MeetingInfo $meetingInfo,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Store\Model\App\Emulation $emulate,
        \Webkul\MpZoom\Model\MeetingInfoRepository $meetingInfoRepo,
        PageFactory $resultPageFactory
    ) {
        $this->zoomHelper = $zoomHelper;
        $this->order = $order;
        $this->meetingInfo = $meetingInfo;
        $this->customerSession = $customerSession;
        $this->emulate = $emulate;
        $this->meetingInfoRepo = $meetingInfoRepo;
        $this->_resultPageFactory = $resultPageFactory;
        parent::__construct($helper, $context, $jsonHelper);
    }
    
    public function execute()
    {
        try {
            $this->verifyRequest();
            $cacheString = "VIEWLIST".$this->storeId.$this->customerToken.$this->customerId;
            if ($this->helper->validateRequestForCache($cacheString, $this->eTag)) {
                return $this->getJsonResponse($this->returnArray, 304);
            }
            $environment = $this->emulate->startEnvironmentEmulation($this->storeId);

            $meetingInfo = $this->meetingInfoRepo->getList()
                            ->addFieldToFilter('seller_id', ['eq' => $this->customerId])->setOrder('order_id','DESC');
            $meetingList = [];
            foreach ($meetingInfo as $data) {
                $order = $this->order->load($data->getOrderId());
                $eachMeeting                 = [];
                $eachMeeting['meeting_id'] = $data->getMeetingId();
                $eachMeeting['product_id'] = $data->getProductId();
                $eachMeeting['order_id'] = $data->getOrderId();
                $eachMeeting['order_increment_id'] = $order->getIncrementId();
                $eachMeeting['host_url'] = $data->getStartUrl();
                $eachMeeting['joining_url'] = $data->getJoiningUrl();
                $eachMeeting['info'] = json_decode($data->getInfo(), true);
                $meetingList[] = $eachMeeting;

            }
            $this->returnArray["success"]   = true;
            $this->returnArray["message"] = "";
            $this->returnArray["meeting_list"] = $meetingList;
            return $this->getJsonResponse($this->returnArray);

        } catch (\Exception $e) {
            $this->returnArray["success"]   = false;
            $this->returnArray["message"] = __($e->getMessage());
            $this->helper->printLog($this->returnArray, 1);
            return $this->getJsonResponse($this->returnArray);
        }
    }

    protected function verifyRequest()
    {
        if ($this->getRequest()->getMethod() == "GET" && $this->wholeData) {
            $this->eTag          = $this->wholeData["eTag"]          ?? "";
            $this->storeId       = $this->wholeData["storeId"]       ?? 0;
            $this->customerToken = $this->wholeData["customerToken"] ?? '';
            $this->customerId    = $this->helper->getCustomerByToken($this->customerToken) ?? 0;
            if (!$this->customerId && $this->customerToken != "") {
                $this->returnArray["otherError"] = "customerNotExist";
                throw new \Magento\Framework\Exception\LocalizedException(
                    __("Customer you are requesting does not exist.")
                );
            } elseif ($this->customerId != 0) {
                $this->customerSession->setCustomerId($this->customerId);
            }

        } else {
            throw new \BadMethodCallException(__("Invalid Request"));
        }
    }
}
