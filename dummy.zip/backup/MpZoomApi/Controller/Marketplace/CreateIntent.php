<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoomApi
 * @author    Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpZoomApi\Controller\Marketplace;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Framework\Exception\LocalizedException;
use Webkul\MpStripe\Logger\StripeLogger;
use Webkul\MpStripe\Model\Source\PaymentAction;

class CreateIntent extends \Webkul\MobikulApi\Controller\ApiController
{

    public $orderFactory;
    public $logger;
    public $stripeHelper;
    /**
     * @var int
     */
    private $orderId;

    /**
     * Undocumented function
     *
     * @param Context $context
     * @param StripeLogger $stripeLogger
     * @param \Webkul\MpStripe\Helper\Data $stripeHelper
     * @param \Webkul\MobikulCore\Helper\Data $mobikulHelper
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     */
    public function __construct(
        Context $context,
        StripeLogger $stripeLogger,
        \Webkul\MpStripe\Helper\Data $stripeHelper,
        \Webkul\MobikulCore\Helper\Data $mobikulHelper,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Magento\Sales\Model\OrderFactory $orderFactory
    ) {
        $this->orderFactory = $orderFactory;
        $this->logger = $stripeLogger;
        $this->stripeHelper = $stripeHelper;
        parent::__construct($mobikulHelper, $context, $jsonHelper);
    }

    /**
     * Create stripe data for checkout page
     */
    public function execute()
    {
        $this->verifyRequest();
        try {
            $quote = $this->orderFactory->create()->loadByIncrementId($this->orderId);
            if ($quote && $quote->getStripePaymentIntent() == "") {
                $finalCart = $this->stripeHelper->getFinalCart($quote);
                $paymentDetails = $this->stripeHelper->getCheckoutFinalData($finalCart, $quote);
                $paymentAction = $this->stripeHelper->getConfigValue('stripe_payment_action');

                $transfer = $this->createStripeTransfer(
                    $paymentDetails,
                    $paymentAction
                );
                $quote->setStripeStripePaymentAction($paymentAction);
                $quote->save();

                $this->returnArray["success"]   = true;
                $this->returnArray["publishable_key"] = $this->stripeHelper->getConfigValue("api_publish_key");
                $this->returnArray["clientSecret"] = $this->stripeHelper->getConfigValue('client_secret');
                $this->returnArray["client_secret"] = isset($transfer['client_secret']) ? $transfer['client_secret'] : "";
                $this->returnArray["stripeId"] = isset($transfer['id']) ? $transfer['id'] : "";
            } else {
                $this->returnArray["success"]   = false;
                $this->returnArray["message"] = "Payment is already completed.";
            }
            return $this->getJsonResponse($this->returnArray);
        } catch (\Exception $e) {
            $this->logger->critical($e->getMessage());
            throw new LocalizedException(
                __(
                    'There was an error capturing the transaction, order has been cancelled',
                    $e->getMessage()
                )
            );
        }
    }

    /**
     * CreateStripeTranfer create stripe transfer.
     *
     * @param array $paymentDetailsArray
     * @param string $paymentAction
     * @return array or bool
     */
    public function createStripeTransfer($paymentDetailsArray, $paymentAction)
    {
        try {
            $finalArray = [];
            if ($paymentAction == PaymentAction::STRIPE_ACTION_AUTHORIZE) {
                $finalArray["capture_method"] = 'manual';
            }
            $finalArray["payment_method_types"] = ["card"];
            $finalArray['amount'] = 0;
            $finalArray['description'] = "The AccessPass Payment";
            $stripeUserAccount = 0;
            $sellerId = 0;
            foreach ($paymentDetailsArray as $paymentDetails) {
                $finalArray['amount'] += $paymentDetails['payment_array']['amount'];
                $finalArray['currency'] = $paymentDetails['payment_array']['currency'];
                $finalArray['transfer_group'] = $paymentDetails['payment_array']['order_id'];

                if ($paymentDetails['cart']['seller'] != 0 &&
                    $this->stripeHelper->isDirectCharge()
                ) {
                    $sellerId = $paymentDetails['cart']['seller'];
                    $finalArray['application_fee_amount'] = $paymentDetails['payment_array']['application_fee'];
                    $stripeUserAccount = $paymentDetails['cart']['stripe_user_id'];
                }
            }
            return $this->createStripeIntent($finalArray, $stripeUserAccount, $sellerId);
        } catch (\Stripe\Error $e) {
            $this->logger->critical($e->getMessage());
            return false;
        }
    }

    /**
     * CreateStripeIntent function
     *
     * @param array $finalArray
     * @param string $stripeUserAccount
     * @param int $sellerId
     * @return void
     */
    public function createStripeIntent($finalArray, $stripeUserAccount, $sellerId)
    {
        try {
            $this->stripeHelper->setUpDefaultDetails();
            if ($sellerId != 0 && $this->stripeHelper->isDirectCharge()) {
                $intent = \Stripe\PaymentIntent::create(
                    $finalArray,
                    [
                        'stripe_account' => $stripeUserAccount
                    ]
                );
            } else {
                $intent = \Stripe\PaymentIntent::create($finalArray);
            }
            return $intent;
        } catch (\Stripe\Error $e) {
            $this->logger->critical($e->getMessage());
            return false;
        }
    }

    /**
     * Undocumented function
     *
     * @return void
     */
    protected function verifyRequest()
    {
        if ($this->getRequest()->getMethod() == "POST" && $this->wholeData) {
            $this->orderId    = $this->wholeData['orderId'] ?? 0;
        } else {
            throw new \BadMethodCallException(__("Invalid Request"));
        }
    }
}
