<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoomApi
 * @author    Webkul <support@webkul.com>
 * @copyright Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html ASL Licence
 * @link      https://store.webkul.com/license.html
 */
namespace Webkul\MpZoomApi\Controller\Marketplace;

use Webkul\MobikulMp\Controller\Marketplace\AbstractMarketplace;

class GetAccountDetails extends AbstractMarketplace
{
    public function execute()
    {
        try {
            $this->verifyRequest();
            $environment      = $this->emulate->startEnvironmentEmulation($this->storeId);
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $zoomHelper = $objectManager->create(\Webkul\MpZoom\Helper\Data::class);
            $sellerId = $this->customerId;
            $zoomData = $zoomHelper->getZoomUserDetail($sellerId);
            // $zoomData = $this->helper->getZoomUserDetail($sellerId);
            $result = json_decode($zoomData, true);

            // return $result;
            
            $this->returnArray["success"] = true;
            $this->returnArray["data"] = $result;
            $this->returnArray["isAccountCreated"] = false;
            if (isset($result['status']) && $result['status'] == 'pending') {
                $this->returnArray["message"] = __('The Zoom Account is not activated. Please activate your account from the link in email.');
            }
            if (isset($zoomUserData['status']) && $zoomUserData['status'] == 'active') {
                $this->returnArray["isAccountCreated"] = true;
            }
            
            $this->emulate->stopEnvironmentEmulation($environment);
            $this->helper->log($this->returnArray, "logResponse", $this->wholeData);
            // $this->checkNGenerateEtag($cacheString);
            return $this->getJsonResponse($this->returnArray);
        } catch (\Exception $e) {
            $this->returnArray["message"] = __($e->getMessage());
            $this->helper->printLog($this->returnArray, 1);
            return $this->getJsonResponse($this->returnArray);
        }
    }

    /**
     * Verify Request function to verify Customer and Request
     *
     * @throws Exception customerNotExist
     * @return json | void
     */
    protected function verifyRequest()
    {
        if ($this->getRequest()->getMethod() == "GET" && $this->wholeData) {
            $this->eTag          = $this->wholeData["eTag"]          ?? 0;
            $this->storeId       = $this->wholeData["storeId"]       ?? 0;
            $this->customerToken = $this->wholeData["customerToken"] ?? '';
            $this->customerId    = $this->helper->getCustomerByToken($this->customerToken) ?? 0;
            if (!$this->customerId && $this->customerToken != "") {
                $this->returnArray["otherError"] = "customerNotExist";
                throw new \Magento\Framework\Exception\LocalizedException(
                    __("Customer you are requesting does not exist.")
                );
            } elseif ($this->customerId != 0) {
                $this->customerSession->setCustomerId($this->customerId);
            }
        } else {
            throw new \BadMethodCallException(__("Invalid Request"));
        }
    }

}
