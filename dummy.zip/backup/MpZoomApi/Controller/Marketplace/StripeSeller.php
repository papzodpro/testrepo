<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoomApi
 * @author    Webkul <support@webkul.com>
 * @copyright Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html ASL Licence
 * @link      https://store.webkul.com/license.html
 */
namespace Webkul\MpZoomApi\Controller\Marketplace;

use Webkul\MobikulMp\Controller\Marketplace\AbstractMarketplace;

class StripeSeller extends AbstractMarketplace
{
    /**
     * Execute function for class SaveProfile
     *
     * @throws LocalizedException
     *
     * @return json | void
     */
    public function execute()
    {
        try {
            $this->verifyRequest();
            $data             = [];
            $sellerId = "";
            $integrationType = "";
            $accessToken = "";
            $stripekey = "";
            $stripeUserId = "";
            $stripePersonId = "";
            $userType = "";
            $refreshToken = "";
            $environment = $this->emulate->startEnvironmentEmulation($this->storeId);
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
	        $stripeCollection = $objectManager->create(\Webkul\MpStripe\Model\ResourceModel\StripeSeller\CollectionFactory::class);	
	        $stripeData = $stripeCollection->create()->addFieldToFilter('seller_id', $this->customerId);
            if ($stripeData->getSize()) {
                $data = $stripeData->getFirstItem();
                $sellerId = $data->getSellerId();
                $integrationType = $data->getIntegrationType();
                $accessToken = $data->getAccessToken();
                $stripekey = $data->getStripekey();
                $stripeUserId = $data->getStripeUserId();
                $stripePersonId = $data->getStripePersonId();
                $userType = $data->getUserType();
                $refreshToken = $data->getRefreshToken();
            }
            $this->returnArray["sellerId"] = $sellerId;
            $this->returnArray["integrationType"] = $integrationType;
            $this->returnArray["accessToken"] = $accessToken;
            $this->returnArray["stripekey"] = $stripekey;
            $this->returnArray["stripeUserId"] = $stripeUserId;
            $this->returnArray["stripePersonId"] = $stripePersonId;
            $this->returnArray["userType"] = $userType;
            $this->returnArray["refreshToken"] = $refreshToken;
            $this->returnArray["success"] = true;
            $this->emulate->stopEnvironmentEmulation($environment);
            return $this->getJsonResponse($this->returnArray);
        } catch (\Exception $e) {
            $this->returnArray["message"] = __($e->getMessage());
            $this->helper->printLog($this->returnArray, 1);
            return $this->getJsonResponse($this->returnArray);
        }
    }


    /**
     * Verify Request function to verify Customer and Request
     *
     * @throws Exception customerNotExist
     * @return json | void
     */
    protected function verifyRequest()
    {
        if ($this->getRequest()->getMethod() == "GET" && $this->wholeData) {
            // $this->storeId            = $this->wholeData["storeId"]            ?? 0;
            // $this->apiKey             = $this->wholeData["apiKey"]             ?? "";
            // $this->apiSecret            = $this->wholeData["apiSecret"]            ?? "";
            $this->customerToken = $this->wholeData["customerToken"] ?? '';
            $this->customerId    = $this->helper->getCustomerByToken($this->customerToken) ?? 0;
            if (!$this->customerId && $this->customerToken != "") {
                $this->returnArray["otherError"] = "customerNotExist";
                throw new \Magento\Framework\Exception\LocalizedException(
                    __("Customer you are requesting does not exist.")
                );
            } elseif ($this->customerId != 0) {
                $this->customerSession->setCustomerId($this->customerId);
            }
        } else {
            throw new \BadMethodCallException(__("Invalid Request"));
        }
    }
}
