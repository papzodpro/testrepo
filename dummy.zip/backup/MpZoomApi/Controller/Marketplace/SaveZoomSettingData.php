<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoomApi
 * @author    Webkul <support@webkul.com>
 * @copyright Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html ASL Licence
 * @link      https://store.webkul.com/license.html
 */
namespace Webkul\MpZoomApi\Controller\Marketplace;

use Webkul\MobikulMp\Controller\Marketplace\AbstractMarketplace;

class SaveZoomSettingData extends AbstractMarketplace
{
    public $apiKey;
    public $apiSecret;
    /**
     * Execute function for class SaveProfile
     *
     * @throws LocalizedException
     *
     * @return json | void
     */
    public function execute()
    {
        try {
            $this->verifyRequest();
            $environment = $this->emulate->startEnvironmentEmulation($this->storeId);
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $zoomConfigCollection = $objectManager->create(\Webkul\MpZoom\Model\ResourceModel\ConfigData\CollectionFactory::class);	
            $zoomConfigData = $zoomConfigCollection->create()->addFieldToFilter('seller_id', $this->customerId);
            if ($zoomConfigData->getSize()) {
                foreach ($zoomConfigData as $data) {
                    $data->setApiKey($this->apiKey);
                    $data->setApiSecret($this->apiSecret);
                    $data->save();
                }
            } else {
                $model = $zoomConfigCollection->create();
                $model->setSellerId($sellerId);
                $model->setApiKey($this->apiKey);
                $model->setApiSecret($this->apiSecret);
                $model->save();
            }
            $this->returnArray["success"] = true;
            $this->returnArray["message"] = __("Zoom Credential was successfully saved.");
            $this->emulate->stopEnvironmentEmulation($environment);
            $this->helper->log($this->returnArray, "logResponse", $this->wholeData);
            return $this->getJsonResponse($this->returnArray);
        } catch (\Exception $e) {
            $this->returnArray["message"] = __($e->getMessage());
            $this->helper->printLog($this->returnArray, 1);
            return $this->getJsonResponse($this->returnArray);
        }
    }


    /**
     * Verify Request function to verify Customer and Request
     *
     * @throws Exception customerNotExist
     * @return json | void
     */
    protected function verifyRequest()
    {
        if ($this->getRequest()->getMethod() == "POST" && $this->wholeData) {
            $this->storeId            = $this->wholeData["storeId"]            ?? 0;
            $this->apiKey             = $this->wholeData["apiKey"]             ?? "";
            $this->apiSecret            = $this->wholeData["apiSecret"]            ?? "";
            $this->customerToken = $this->wholeData["customerToken"] ?? '';
            $this->customerId    = $this->helper->getCustomerByToken($this->customerToken) ?? 0;
            if (!$this->customerId && $this->customerToken != "") {
                $this->returnArray["otherError"] = "customerNotExist";
                throw new \Magento\Framework\Exception\LocalizedException(
                    __("Customer you are requesting does not exist.")
                );
            } elseif ($this->customerId != 0) {
                $this->customerSession->setCustomerId($this->customerId);
            }
        } else {
            throw new \BadMethodCallException(__("Invalid Request"));
        }
    }
}
