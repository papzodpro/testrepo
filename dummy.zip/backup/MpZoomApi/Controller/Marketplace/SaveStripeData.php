<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoomApi
 * @author    Webkul <support@webkul.com>
 * @copyright Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html ASL Licence
 * @link      https://store.webkul.com/license.html
 */
namespace Webkul\MpZoomApi\Controller\Marketplace;

use Webkul\MobikulMp\Controller\Marketplace\AbstractMarketplace;

class SaveStripeData extends AbstractMarketplace
{
    public $customerModel;
    public $apiKey;
    public $refreshToken;
    public $accessToken;
    public $stripeUserId;
    public $userType;
    public $integrationType;
    /**
     * Execute function for class SaveProfile
     *
     * @throws LocalizedException
     *
     * @return json | void
     */

    // public function __construct(
    //     \Magento\Customer\Model\CustomerFactory $customerModel
    // ) {
    //     $this->customerModel = $customerModel;
    // }

    public function execute()
    {
        try {
            $this->verifyRequest();
            $environment = $this->emulate->startEnvironmentEmulation($this->storeId);
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $stripeCollection = $objectManager->create(\Webkul\MpStripe\Model\ResourceModel\StripeSeller\CollectionFactory::class);
	        $stripeData = $stripeCollection->create()->addFieldToFilter('seller_id', $this->customerId);
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $this->customerModel = $objectManager->create(\Magento\Customer\Model\CustomerFactory::class);
            $seller = $this->customerModel->create()->load($this->customerId);
            if ($stripeData->getSize()) {
                foreach ($stripeData as $data) {
                    $data->setEmail($seller->getEmail());
                    $data->setStoreId($this->storeId);
                    $data->setWebsiteId($this->websiteId);
                    $data->setStripekey($this->apiKey);
                    $data->setRefreshToken($this->refreshToken);
                    $data->setAccessToken($this->accessToken);
                    $data->setStripeUserId($this->stripeUserId);
                    $data->setUserType($this->userType);
                    $data->setIntegrationType($this->integrationType);
                    $data->save();
                }
            } else {
                $stripeModel = $objectManager->create(\Webkul\MpStripe\Model\StripeSellerFactory::class);
                $model = $stripeModel->create();
                $model->setEmail($seller->getEmail());
                $model->setSellerId($this->customerId);
                $model->setStoreId($this->storeId);
                $model->setWebsiteId($this->websiteId);
                $model->setStripekey($this->apiKey);
                $model->setRefreshToken($this->refreshToken);
                $model->setAccessToken($this->accessToken);
                $model->setStripeUserId($this->stripeUserId);
                $model->setUserType($this->userType);
                $model->setIntegrationType($this->integrationType);
                $model->save();
            }
            $this->returnArray["success"] = true;
            $this->returnArray["message"] = __("Stripe Data saved successfully");
            $this->emulate->stopEnvironmentEmulation($environment);
            return $this->getJsonResponse($this->returnArray);
        } catch (\Exception $e) {
            $this->returnArray["message"] = __($e->getMessage());
            $this->helper->printLog($this->returnArray, 1);
            return $this->getJsonResponse($this->returnArray);
        }
    }


    /**
     * Verify Request function to verify Customer and Request
     *
     * @throws Exception customerNotExist
     * @return json | void
     */
    protected function verifyRequest()
    {
        if ($this->getRequest()->getMethod() == "POST" && $this->wholeData) {
            $this->storeId            = $this->wholeData["storeId"]           ?? 0;
            $this->websiteId          = $this->wholeData["websiteId"]         ?? 0;
            $this->apiKey             = $this->wholeData["stripekey"]         ?? "";
            $this->refreshToken       = $this->wholeData["refreshToken"]      ?? "";
            $this->accessToken        = $this->wholeData["accessToken"]       ?? "";
            $this->stripeUserId       = $this->wholeData['stripeUserId']      ?? ""; 
            $this->userType           = $this->wholeData['userType']          ?? ""; 
            $this->integrationType    = $this->wholeData['integrationType']   ?? 2 ; 
            $this->customerToken = $this->wholeData["customerToken"] ?? '';
            $this->customerId    = $this->helper->getCustomerByToken($this->customerToken) ?? 0;
            if (!$this->customerId && $this->customerToken != "") {
                $this->returnArray["otherError"] = "customerNotExist";
                throw new \Magento\Framework\Exception\LocalizedException(
                    __("Customer you are requesting does not exist.")
                );
            } elseif ($this->customerId != 0) {
                $this->customerSession->setCustomerId($this->customerId);
            }
        } else {
            throw new \BadMethodCallException(__("Invalid Request"));
        }
    }
}
