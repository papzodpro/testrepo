<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoom
 * @author    Webkul
 * @copyright Copyright (c)  Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpZoom\Helper;

use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Customer\Model\Session as CustomerSession;
use Firebase\JWT\JWT;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;

/**
 * helper class.
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{

    public $logger;
    public $meetinginfoRepo;
    public $meetinginfoFactory;
    /**
     * @var \Webkul\MpZoom\Model\ResourceModel\MeetingInfo\CollectionFactory
     */
    public $collectionFactory;
    public $configCollection;
    public $messageManager;
    public $mpHelper;
    public $customerFactory;
    public $inlineTranslation;
    public $transportBuilder;
    public $_curl;
    /**
     * @var \Magento\Framework\HTTP\Adapter\Curl
     */
    public $adapterCurl;
    /**
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    public $timezone;
    public $temp_id;
    public const CREATE_USERS_URL = "https://api.zoom.us/v2/users/";

    /**
     * @var CustomerSession
     */
    protected $_customerSession;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var ProductRepositoryInterface
     */
    protected $_productRepository;

    /**
     * @var \Webkul\MpAdvancedBookingSystem\Helper\Data
     */
    protected $_bookingHelper;
   
    /**
     * __construct function
     *
     * @param CustomerSession $customerSession
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param ScopeConfigInterface $scopeConfig
     * @param \Psr\Log\LoggerInterface $logger
     * @param ProductRepositoryInterface $productRepository
     * @param \Webkul\MpZoom\Model\MeetingInfoRepository $meetinginfoRepo
     * @param \Webkul\MpZoom\Model\MeetingInfoFactory $meetinginfoFactory
     * @param \Webkul\MpZoom\Model\ResourceModel\MeetingInfo\CollectionFactory $collectionFactory
     * @param \Webkul\MpZoom\Model\ResourceModel\ConfigData\CollectionFactory $configCollection
     * @param \Magento\Framework\Message\ManagerInterface $messageManager
     * @param \Webkul\Marketplace\Helper\Data $mpHelper
     * @param \Magento\Customer\Model\CustomerFactory $customerFactory
     * @param \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
     * @param \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone
     * @param \Magento\Framework\HTTP\Client\Curl $curl
     * @param \Webkul\MpAdvancedBookingSystem\Helper\Data $bookingHelper
     * @param \Magento\Framework\HTTP\Adapter\Curl $adapterCurl
     */
    public function __construct(
        CustomerSession $customerSession,
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        ScopeConfigInterface $scopeConfig,
        \Psr\Log\LoggerInterface $logger,
        ProductRepositoryInterface $productRepository,
        \Webkul\MpZoom\Model\MeetingInfoRepository $meetinginfoRepo,
        \Webkul\MpZoom\Model\MeetingInfoFactory $meetinginfoFactory,
        \Webkul\MpZoom\Model\ResourceModel\MeetingInfo\CollectionFactory $collectionFactory,
        \Webkul\MpZoom\Model\ResourceModel\ConfigData\CollectionFactory $configCollection,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Webkul\Marketplace\Helper\Data $mpHelper,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone,
        \Magento\Framework\HTTP\Client\Curl $curl,
        \Webkul\MpAdvancedBookingSystem\Helper\Data $bookingHelper,
        \Magento\Framework\HTTP\Adapter\Curl $adapterCurl
    ) {
        $this->_customerSession = $customerSession;
        $this->_storeManager = $storeManager;
        $this->scopeConfig = $scopeConfig;
        $this->logger = $logger;
        $this->meetinginfoRepo = $meetinginfoRepo;
        $this->meetinginfoFactory = $meetinginfoFactory;
        $this->collectionFactory = $collectionFactory;
        $this->configCollection = $configCollection;
        $this->messageManager = $messageManager;
        $this->mpHelper = $mpHelper;
        $this->customerFactory = $customerFactory;
        $this->inlineTranslation = $inlineTranslation;
        $this->transportBuilder = $transportBuilder;
        $this->_curl = $curl;
        $this->adapterCurl = $adapterCurl;
        $this->timezone = $timezone;
        $this->_bookingHelper = $bookingHelper;
        $this->_productRepository = $productRepository;
        parent::__construct($context);
    }

    /**
     * Get token for zoom apis
     *
     * @return string
     */
    public function getZoomAccessToken()
    {
        $apiKey = $this->getConfigValue('marketplace_zoom/general_settings/api_key');
        $apiSecret = $this->getConfigValue('marketplace_zoom/general_settings/api_secret');
        $apiAccountId = $this->getConfigValue('marketplace_zoom/general_settings/api_account_id');
        try {
            $tokenUrl = 'https://zoom.us/oauth/token?grant_type=account_credentials&account_id='.$apiAccountId;
            $this->_curl->setCredentials($apiKey, $apiSecret);
            $this->_curl->post($tokenUrl, '{}');
            $response = $this->_curl->getBody();
            $result = json_decode($response, true);
            return $result['access_token']??"";
        } catch (LocalizedException $e) {
            $this->logger->info(__('curl exception '.$e->getMessage()));
            $this->messageManager->addErrorMessage(__($e->getMessage()));

        }
    }
    
    /**
     * Get getSellerConfigData
     *
     * @param int $sellerId
     * @return object
     */
    public function getSellerConfigData($sellerId)
    {
        $collection = $this->configCollection->create()->addFieldToFilter('seller_id', $sellerId);
        return $collection->getFirstItem();
    }

    /**
     * Return store configuration value.
     *
     * @param string $path
     *
     * @return mixed
     */
    protected function getConfigValue($path)
    {
        return $this->scopeConfig->getValue(
            $path,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * Get Store
     */
    public function getStore()
    {
        return $this->_storeManager->getStore();
    }

    /**
     * Create new zoom user
     *
     * @param int $sellerId
     * @return string
     */
    public function createZoomUser($sellerId)
    {
        $sellerColl = $this->mpHelper->getSellerDataBySellerId($sellerId);
        $sellerData = $sellerColl->getFirstItem();

        $userData = [
            "action" => "create",
            "user_info" => [
                "email" => $sellerData->getEmail(),
                "type" => 1,
                "first_name"=> $sellerData->getName(),
            ]
        ];
        $url = self::CREATE_USERS_URL;
        $result = $this->getCurlPostData($userData, $url);
        $result = json_decode($result, true);
        return $result;
    }

    /**
     * Check if zoom user already exist
     *
     * @param int $productId
     * @return bool|string
     */
    public function isZoomUserExist($productId)
    {
        $sellerId = $this->mpHelper->getSellerIdByProductId($productId);
        if (!$sellerId) {
            return 'me';
        }
        $zoomData = $this->getZoomUserDetail($sellerId);

        $result = json_decode($zoomData, true);
        if (isset($result['email'])) {
            return $result['email'];
        }
        return false;
    }

    /**
     * GetZoomUserDetail function
     *
     * @param [type] $sellerId
     * @return string
     */
    public function getZoomUserDetail($sellerId)
    {
        $sellerColl = $this->mpHelper->getSellerDataBySellerId($sellerId);
        $sellerData = $sellerColl->getFirstItem();

        $url = 'https://api.zoom.us/v2/users/'.$sellerData->getEmail();
        $result = $this->getCurlGetData($url);

        return $result;
    }

    /**
     * Curl post request
     *
     * @param array $data
     * @param string $url
     * @return json
     */
    public function getCurlPostData($data, $url)
    {
        $header = [
            "Content-Type" => "application/json",
            "Authorization" => 'Bearer '.$this->getZoomAccessToken(),
        ];
        try {
            $this->_curl->setHeaders($header);
            $this->_curl->post($url, json_encode($data));
            $response = $this->_curl->getBody();

            return $response;
        } catch (LocalizedException $e) {
            $this->logger->info(__('curl exception '.$e->getMessage()));
            $this->messageManager->addErrorMessage(__($e->getMessage()));

        }
    }

    /**
     * Send curn get request
     *
     * @param string $url
     * @return json
     */
    public function getCurlGetData($url)
    {
        $header = [
            "Content-Type" => "application/json",
            "Authorization" => 'Bearer '.$this->getZoomAccessToken(),
        ];
        try {
            $this->_curl->setHeaders($header);
            $this->_curl->get($url);
            $response = $this->_curl->getBody();

            return $response;
        } catch (LocalizedException $e) {
            $this->logger->info(__('curl exception '.$e->getMessage()));
            $this->messageManager->addErrorMessage(__($e->getMessage()));

        }
    }

    /**
     * Creating new meeting
     *
     * @param array $data
     * @param int $userId
     * @return void
     */
    public function createZoomMeeting($data, $userId)
    {
        $url = 'https://api.zoom.us/v2/users/'.$userId.'/meetings/';
        $result = $this->getCurlPostData($data, $url);
        
        return $result;
    }

    /**
     * Generate random password for zoom meeting
     *
     * @return string
     */
    public function generateRandomPwd()
    {
        $data = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz';
        return substr(str_shuffle($data), 0, 7);
    }

    /**
     * Save meeting info
     *
     * @param json $meetingInfo
     * @param int $orderId
     * @param int $productId
     * @param int $itemId
     * @return void
     */
    public function saveMeetingDetails($meetingInfo, $orderId, $productId, $itemId)
    {
        $meetingData = json_decode($meetingInfo, true);
        $sellerId = $this->mpHelper->getSellerIdByProductId($productId);
        try {
            $meeting = $this->meetinginfoFactory->create()->getCollection()->addFieldToFilter(
                "meeting_id",
                $meetingData['id']
            );
            $meetingOrder = $this->meetinginfoFactory->create()->getCollection()
                ->addFieldToFilter("order_id", $orderId);
            if (!$meeting->getSize() && !$meetingOrder->getSize()) {
                $meetingInfoModel = $this->meetinginfoFactory->create()
                                        ->setMeetingId($meetingData['id'])
                                        ->setOrderId($orderId)
                                        ->setProductId($productId)
                                        ->setStartUrl($meetingData['start_url'])
                                        ->setJoiningUrl($meetingData['join_url'])
                                        ->setSellerId($sellerId)
                                        ->setItemId($itemId)
                                        ->setInfo($meetingInfo);
                $this->meetinginfoRepo->save($meetingInfoModel);
            }
        } catch (\Exception $e) {
            $this->logger->info(__('saving meeting Info '.$e->getMessage()));
            $this->messageManager->addErrorMessage(__($e->getMessage()));
        }
    }

    /**
     * Get seller email by id
     *
     * @param int $id
     * @return string
     */
    public function getSellerEmail($id)
    {
        $customer = $this->customerFactory->create()->load($id);
        return $customer->getEmail();
    }

    /**
     * Send mail to customer of meeting details
     *
     * @param json $meetingInfo
     * @param int $productId
     * @param \Magento\Catalog\Model\Order $order
     * @return void
     */
    public function sendCustomerMail($meetingInfo, $productId, $order)
    {
        $template_name = "marketplace_zoom/email/customer";
        $senderMail = $this->mpHelper->getAdminEmailId();
        $senderName = 'Admin';
        $bccInfo = $senderMail;
        
        if ($sellerId = $this->mpHelper->getSellerIdByProductId($productId)) {
            $bccInfo = $this->getSellerEmail($sellerId);
        }
        
        $receiverInfo = ['name'=>$order->getCustomerFirstName(),'email'=>$order->getCustomerEmail()];
        $senderInfo = ['name'=>$senderName,'email'=>$senderMail];

        $meetingData = json_decode($meetingInfo, true);
        $emailTempVariables['topic']    = $meetingData['topic'];
        $emailTempVariables['name']     = $receiverInfo['name'];
        $emailTempVariables['join_url'] = $meetingData['join_url'];
        $emailTempVariables['password'] = $meetingData['password'];

        $this->sendMail(
            $template_name,
            $emailTempVariables,
            $senderInfo,
            $receiverInfo,
            $bccInfo
        );
    }

    /**
     * Send mail to customer of meeting details
     *
     * @param json $meetingInfo
     * @param int $productId
     * @param \Magento\Catalog\Model\Order $order
     * @return void
     */
    public function sendHostMail($meetingInfo, $productId, $order)
    {
        $template_name = "marketplace_zoom/email/host";
        
        $senderMail = $this->mpHelper->getAdminEmailId();
        $senderName = 'Admin';
        
        $receiverInfo = ['name'=>$senderName,'email'=>$senderMail];
        $senderInfo = ['name'=>$senderName,'email'=>$senderMail];
        
        if ($sellerId = $this->mpHelper->getSellerIdByProductId($productId)) {
            $sellerMail = $this->getSellerEmail($sellerId);
            $sellerName = $this->getSellerName($sellerId);
            $receiverInfo = ['name'=>$sellerName,'email'=>$sellerMail];
        }
        $meetingData = json_decode($meetingInfo, true);
        $emailTempVariables['topic']    = $meetingData['topic'];
        $emailTempVariables['name']     = $receiverInfo['name'];
        $emailTempVariables['host_url'] = $meetingData['start_url'];

        $this->sendMail(
            $template_name,
            $emailTempVariables,
            $senderInfo,
            $receiverInfo
        );
    }

    /**
     * Send mail to sellers
     *
     * @param string $template_name
     * @param array $emailTempVariables
     * @param array $senderInfo
     * @param array $receiverInfo
     * @param bool $bccInfo
     */
    public function sendMail(
        $template_name,
        $emailTempVariables,
        $senderInfo,
        $receiverInfo,
        $bccInfo = false
    ) {
        $this->temp_id = $this->getTemplateId($template_name);
        $this->inlineTranslation->suspend();
        $this->generateTemplate($emailTempVariables, $senderInfo, $receiverInfo);
        if ($bccInfo) {
            $this->transportBuilder->addBcc($bccInfo);
        }
        $transport = $this->transportBuilder->getTransport();
        $transport->sendMessage();
        $this->inlineTranslation->resume();
    }

    /**
     * Get Template Id
     *
     * @param string $xmlPath
     * @return void
     */
    public function getTemplateId($xmlPath)
    {
        return $this->getConfigValue($xmlPath, $this->getStore()->getStoreId());
    }

    /**
     * Generate Template
     *
     * @param array $emailTemplateVariables
     * @param array $senderInfo
     * @param array $receiverInfo
     */
    public function generateTemplate($emailTemplateVariables, $senderInfo, $receiverInfo)
    {
        $template =  $this->transportBuilder->setTemplateIdentifier($this->temp_id)
                ->setTemplateOptions(
                    [
                        'area' => \Magento\Framework\App\Area::AREA_ADMINHTML,
                        'store' => $this->_storeManager->getStore()->getId(),
                    ]
                )
                ->setTemplateVars($emailTemplateVariables)
                ->setFrom($senderInfo)
                ->addTo($receiverInfo['email'], $receiverInfo['name']);
        return $this;
    }

    /**
     * Get Customer Name By Id
     *
     * @param string $id
     *
     * @return array
     */
    public function getSellerName($id)
    {
        $customer = $this->customerFactory->create()->load($id);
        return $customer->getFirstname();
    }

    /**
     * End zoom meeting
     *
     * @param array $data
     * @param long $meetingId
     * @return void
     */
    public function endMeeting($data, $meetingId)
    {
        $url = 'https://api.zoom.us/v2/meetings/'.$meetingId.'/status';
        $result = $this->sendPutRequest($data, $url);
        return $result;
    }
    
    /**
     * Create Meeting
     *
     * @param object $order
     * @return array
     */
    public function craeteMeetingLink($order)
    {
        $response = [
            'success' => false,
            'message' => __('Order not created.')
        ];
        try {
            foreach ($order->getAllItems() as $item) {
                $bookingDate = '';
                $bookingTime = '';
                $product = $this->_productRepository->getById($item->getProductId());
                $helper = $this->_bookingHelper;
                $customAttrSetId = $helper->getProductAttributeSetIdByLabel(
                    'Custom Slot Product'
                );
                if ($item->getProductType() == 'booking' && $customAttrSetId != $product->getAttributeSetId()) {
                    $buyInfo = $item->getProductOptions()['info_buyRequest'];
                    if (isset($buyInfo['booking_date']) && isset($buyInfo['booking_time'])) {  
                        $bookingDate = $buyInfo['booking_date'];
                        $bookingTime = $buyInfo['booking_time'];
                    } else {
                        $i = 0;
                        foreach ($buyInfo['options'] as $optionVal) {
                            if ($i == 0) {
                                $bookingDate = $optionVal;
                            } else {
                                $bookingTime = $optionVal;
                            }
                            $i++;
                        }
                        
                    }
                    
                    $date = date_create($bookingDate);
                    $bookingDate = date_format($date, "Y-m-d");
                    $bookingTime = date("H:i:s", strtotime($bookingTime));
                    $timezone = $this->getTimezone($item);
                    $meetingData = [
                        "topic"=> $item->getName(),
                        "type"=> "2",
                        "start_time"=> $bookingDate."T".$bookingTime,
                        "duration"=> $product->getSlotDuration(),
                        "timezone"=> $timezone,
                        "password"=> $this->generateRandomPwd(),
                        "agenda"=> $item->getName()
                    ];
                    $zoomUserEmail = $this->isZoomUserExist($item->getProductId());
                    if ($zoomUserEmail) {
                        $userId = $zoomUserEmail;
                    } else {
                        $response = [
                            'success' => false,
                            'message' => __('Please create a zoom user to place an order.')
                        ];
                    }
                    $meetingInfo = $this->createZoomMeeting($meetingData, $userId);
                    $this->saveMeetingDetails(
                        $meetingInfo,
                        $order->getId(),
                        $item->getProductId(),
                        $item->getItemId()
                    );
                    try {
                        $this->sendCustomerMail($meetingInfo, $item->getProductId(), $order);
                        $this->sendHostMail($meetingInfo, $item->getProductId(), $order);
                    } catch (\Exception $e) {
                        $this->_bookingHelper->logDataInLogger(
                            "send_meeting_link Exception : ".$e->getMessage()
                        );
                    }
                    $response = [
                        'success' => true,
                        'message' => __('Meeting Link created successfully.')
                    ];
                } else {
                    $response = [
                        'success' => true,
                        'message' => __('You will get your slot soon.')
                    ];
                }
            }
        } catch (\Exception $e) {
            $response = [
                'success' => false,
                'message' => __('Something went wrong while creating meeting link.')
            ];
            $this->_bookingHelper->logDataInLogger(
                "create_meeting_link Exception : ".$e->getMessage()
            );
        }
        return $response;
    }

    /**
     * Get Timezone
     *
     * @param object $item
     * @return string
     */
    public function getTimezone($item)
    {
        $sellerId = $this->mpHelper->getSellerIdByProductId($item->getProductId());
        return $this->_bookingHelper->getSellerTimeZone($sellerId);
    }
    
    /**
     * Delete zoom meeting
     *
     * @param long $meetingId
     * @return void
     */
    public function deleteMeeting($meetingId)
    {
        $data = [];
        $url = 'https://api.zoom.us/v2/meetings/'.$meetingId;
        $result = $this->curlDel($url);
        return $result;
    }
    
    /**
     * Delete
     *
     * @param string $url
     * @return string
     */
    public function curlDel($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "Content-Type: application/json",
            "Authorization: Bearer ".$this->getZoomAccessToken()
        ));
        $result = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
    
        return $result;
    }

    /**
     * Senf Request
     *
     * @param array $data
     * @param string $url
     * @return void
     */
    public function sendPutRequest($data, $url)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "PUT",
            CURLOPT_POSTFIELDS =>json_encode($data),
            CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json",
                "Authorization: Bearer ".$this->getZoomAccessToken()
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
    }
}
