<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoom
 * @author    Webkul
 * @copyright Copyright (c)  Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpZoom\Helper;

use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Customer\Model\Session as CustomerSession;
use Firebase\JWT\JWT;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;

/**
 * helper class.
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{

    public $logger;
    public $meetinginfoRepo;
    public $meetinginfoFactory;
    /**
     * @var \Webkul\MpZoom\Model\ResourceModel\MeetingInfo\CollectionFactory
     */
    public $collectionFactory;
    public $configCollection;
    public $messageManager;
    public $mpHelper;
    public $customerFactory;
    public $inlineTranslation;
    public $transportBuilder;
    public $_curl;
    public $temp_id;
    const CREATE_MEETING_URL = "https://api.zoom.us/v2/users/me/meetings/";

    /**
     * Customer session.
     *
     * @var CustomerSession
     */
    protected $_customerSession;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
   
    /**
     * construct
     *
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Framework\HTTP\Client\Curl $curl
     */
    public function __construct(
        CustomerSession $customerSession,
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        ScopeConfigInterface $scopeConfig,
        \Psr\Log\LoggerInterface $logger,
        \Webkul\MpZoom\Model\MeetingInfoRepository $meetinginfoRepo,
        \Webkul\MpZoom\Model\MeetingInfoFactory $meetinginfoFactory,
        \Webkul\MpZoom\Model\ResourceModel\MeetingInfo\CollectionFactory $collectionFactory,
        \Webkul\MpZoom\Model\ResourceModel\ConfigData\CollectionFactory $configCollection,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Webkul\Marketplace\Helper\Data $mpHelper,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\HTTP\Client\Curl $curl
    ) {
        $this->_customerSession = $customerSession;
        $this->_storeManager = $storeManager;
        $this->scopeConfig = $scopeConfig;
        $this->logger = $logger;
        $this->meetinginfoRepo = $meetinginfoRepo;
        $this->meetinginfoFactory = $meetinginfoFactory;
        $this->collectionFactory = $collectionFactory;
        $this->configCollection = $configCollection;
        $this->messageManager = $messageManager;
        $this->mpHelper = $mpHelper;
        $this->customerFactory = $customerFactory;
        $this->inlineTranslation = $inlineTranslation;
        $this->transportBuilder = $transportBuilder;
        $this->_curl = $curl;
        parent::__construct($context);
    }

    /**
     * get token for zoom apis
     *
     * @return string
     */
    public function getZoomAccessToken($productId)
    {
        $sellerId = $this->mpHelper->getSellerIdByProductId();
        if ($sellerId) {
            $sellerConfigData = $this->getSellerConfigData($sellerId);
            $apiKey = $sellerConfigData->getApiKey();
            $apiSecret = $sellerConfigData->getApiSecret();
        } else {
            $apiKey = $this->getConfigValue('marketplace_zoom/general_settings/api_key');
            $apiSecret = $this->getConfigValue('marketplace_zoom/general_settings/api_secret');
        }
        $payload = [
            "iss" =>$apiKey,
            'exp' => time() + 3600,
        ];
        return JWT::encode($payload, $apiSecret);
    }
    
    public function getSellerConfigData($sellerId)
    {
        
        $collection = $this->configCollection->create()->addFieldToFilter('seller_id', $sellerId);
        
        return $collection->getFirstItem();
    }

    /**
     * Return store configuration value.
     *
     * @param string $path
     * @param int    $storeId
     *
     * @return mixed
     */
    protected function getConfigValue($path)
    {
        return $this->scopeConfig->getValue(
            $path,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * Get Store
     */
    public function getStore()
    {
        return $this->_storeManager->getStore();
    }

    /**
     * send curl request for creating new meeting
     *
     * @param array $data
     * @return void
     */
    public function createZoomMeeting($data, $productId)
    {
        $type = 'POST';
        $header = [
            "Content-Type" => "application/json",
            "Authorization" => 'Bearer '.$this->getZoomAccessToken($productId),
        ];
        try {
            $this->_curl->setHeaders($header);
            $this->_curl->post(self::CREATE_MEETING_URL, json_encode($data));
            $response = $this->_curl->getBody();

            return $response;
        } catch (LocalizedException $e) {
            $this->logger->info(__('curl exception '.$e->getMessage()));
            $this->messageManager->addErrorMessage(__($e->getMessage()));

        }
    }

    /**
     * generate random password for zoom meeting
     *
     * @return string
     */
    public function generateRandomPwd()
    {
        $data = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz';
        return substr(str_shuffle($data), 0, 7);
    }

    /**
     * save meeting info
     *
     * @param json $meetingInfo
     * @param int $orderId
     * @param int $productId
     * @return void
     */
    public function saveMeetingDetails($meetingInfo, $orderId, $productId, $itemId)
    {
        $meetingData = json_decode($meetingInfo, true);
        // print_r($meetingData);die;
        $sellerId = $this->mpHelper->getSellerIdByProductId($productId);
        try {
            $meetingInfoModel = $this->meetinginfoFactory->create()
                                        ->setMeetingId($meetingData['id'])
                                        ->setOrderId($orderId)
                                        ->setProductId($productId)
                                        ->setStartUrl($meetingData['start_url'])
                                        ->setJoiningUrl($meetingData['join_url'])
                                        ->setSellerId($sellerId)
                                        ->setItemId($itemId)
                                        ->setInfo($meetingInfo);
            $this->meetinginfoRepo->save($meetingInfoModel);
                // print_r($meetingData);die;
            // $collection = $this->collectionFactory->create()->addFieldToFilter('order_id', $orderId)
            //                                                 ->addFieldToFilter('product_id', $productId);
            // if (!$collection->getSize()) {
            //     $meetingInfoModel = $this->meetinginfoFactory->create()
            //                             ->setMeetingId($meetingData['id'])
            //                             ->setOrderId($orderId)
            //                             ->setProductId($productId)
            //                             ->setStartUrl($meetingData['start_url'])
            //                             ->setJoiningUrl($meetingData['join_url'])
            //                             ->setSellerId($sellerId)
            //                             ->setinfo($meetingInfo);

            //     $this->meetinginfoRepo->save($meetingInfoModel);
            // } else {
            //     $collData = $collection->getFirstItem();
            //     $id = $collData->getId();
            //     $meetingInfoModel = $this->meetinginfoFactory->create()->load($id)
            //                             ->setMeetingId($meetingData['id'])
            //                             ->setOrderId($orderId)
            //                             ->setProductId($productId)
            //                             ->setStartUrl($meetingData['start_url'])
            //                             ->setJoiningUrl($meetingData['join_url'])
            //                             ->setinfo($meetingInfo);
            //     $this->meetinginfoRepo->save($meetingInfoModel);
            // }
            
        } catch (\Exception $e) {
            $this->logger->info(__('saving meeting Info '.$e->getMessage()));
            $this->messageManager->addErrorMessage(__($e->getMessage()));
        }
    }

    /**
     * get seller email by id
     *
     * @param int $id
     * @return string
     */
    public function getSellerEmail($id)
    {
        $customer = $this->customerFactory->create()->load($id);
        return $customer->getEmail();
    }

    /**
     * send mail to customer of meeting details
     *
     * @param json $meetingInfo
     * @param int $productId
     * @param \Magento\Catalog\Model\Order $order
     * @return void
     */
    public function sendCustomerMail($meetingInfo, $productId, $order)
    {
        $template_name = "marketplace_zoom/email/customer";
        if ($sellerId = $this->mpHelper->getSellerIdByProductId($productId)) {
            $senderMail = $this->getSellerEmail($sellerId);
            $senderName = $this->getSellerName($sellerId);
        } else {
            $senderMail = $this->mpHelper->getAdminEmailId();
            $senderName = 'Admin';
        }
        $receiverInfo = ['name'=>$order->getCustomerFirstName(),'email'=>$order->getCustomerEmail()];
        $senderInfo = ['name'=>$senderName,'email'=>$senderMail];

        $meetingData = json_decode($meetingInfo, true);
        $emailTempVariables['topic']    = $meetingData['topic'];
        $emailTempVariables['name']     = $receiverInfo['name'];
        $emailTempVariables['join_url'] = $meetingData['join_url'];
        $emailTempVariables['password'] = $meetingData['password'];

        $this->sendMail(
            $template_name,
            $emailTempVariables,
            $senderInfo,
            $receiverInfo
        );
    }

    /**
     * send mail to customer of meeting details
     *
     * @param json $meetingInfo
     * @param int $productId
     * @param \Magento\Catalog\Model\Order $order
     * @return void
     */
    public function sendHostMail($meetingInfo, $productId, $order)
    {
        $template_name = "marketplace_zoom/email/host";
        if ($sellerId = $this->mpHelper->getSellerIdByProductId($productId)) {
            $senderMail = $this->getSellerEmail($sellerId);
            $senderName = $this->getSellerName($sellerId);
        } else {
            $senderMail = $this->mpHelper->getAdminEmailId();
            $senderName = 'Admin';
        }
        $receiverInfo = ['name'=>$senderName,'email'=>$senderMail];
        $senderInfo = ['name'=>$senderName,'email'=>$senderMail];

        $meetingData = json_decode($meetingInfo, true);
        $emailTempVariables['topic']    = $meetingData['topic'];
        $emailTempVariables['name']     = $receiverInfo['name'];
        $emailTempVariables['host_url'] = $meetingData['start_url'];

        $this->sendMail(
            $template_name,
            $emailTempVariables,
            $senderInfo,
            $receiverInfo
        );
    }

    /**
     * Send mail to sellers
     *
     * @param string $template_name
     * @param array $emailTempVariables
     * @param array $senderInfo
     * @param array $receiverInfo
     */
    public function sendMail(
        $template_name,
        $emailTempVariables,
        $senderInfo,
        $receiverInfo
    ) {
        $this->temp_id = $this->getTemplateId($template_name);
        $this->inlineTranslation->suspend();
        $this->generateTemplate($emailTempVariables, $senderInfo, $receiverInfo);
        $transport = $this->transportBuilder->getTransport();
        $transport->sendMessage();
        $this->inlineTranslation->resume();
    }

    /**
     * Get Template Id
     */
    public function getTemplateId($xmlPath)
    {
        return $this->getConfigValue($xmlPath, $this->getStore()->getStoreId());
    }

    /**
     * Generate Template
     *
     * @param array $emailTempVariables
     * @param array $senderInfo
     * @param array $receiverInfo
     */
    public function generateTemplate($emailTemplateVariables, $senderInfo, $receiverInfo)
    {
        $template =  $this->transportBuilder->setTemplateIdentifier($this->temp_id)
                ->setTemplateOptions(
                    [
                        'area' => \Magento\Framework\App\Area::AREA_ADMINHTML,
                        'store' => $this->_storeManager->getStore()->getId(),
                    ]
                )
                ->setTemplateVars($emailTemplateVariables)
                ->setFrom($senderInfo)
                ->addTo($receiverInfo['email'], $receiverInfo['name']);
        return $this;
    }

    /**
     * Get Customer Name By Id
     *
     * @param string $ids
     *
     * @return array
     */
    public function getSellerName($id)
    {
        $customer = $this->customerFactory->create()->load($id);
        return $customer->getFirstname();
    }
}
