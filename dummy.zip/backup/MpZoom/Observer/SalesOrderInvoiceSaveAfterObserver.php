<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoom
 * @author    Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */

namespace Webkul\MpZoom\Observer;

use Magento\Framework\Event\ObserverInterface;
use Webkul\MpStripe\Model\Source\PaymentAction;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Webkul\MpStripe\Model\PaymentMethod;

/**
 * Webkul Marketplace SalesOrderInvoiceSaveAfterObserver Observer Model.
 */
class SalesOrderInvoiceSaveAfterObserver implements ObserverInterface
{
    /**
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    public $timezone;
    public $zoomHelper;
    public $stripeHelper;
    /**
     * @var CustomerRepositoryInterface
     */
    protected $_customerRepository;

    /**
     * @var ProductRepositoryInterface
     */
    protected $_productRepository;

    /**
     * @var Webkul\MpAdvancedBookingSystem\Helper\Data
     */
    protected $_bookingHelper;

    /**
     * __construct function
     *
     * @param \Webkul\MpStripe\Helper\Data $helper
     * @param \Webkul\MpZoom\Helper\Data $zoomHelper
     * @param \Webkul\MpStripe\Helper\Data $stripeHelper
     * @param ProductRepositoryInterface $productRepository
     * @param \Webkul\MpAdvancedBookingSystem\Helper\Data $bookingHelper
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone
     */
    public function __construct(
        \Webkul\MpStripe\Helper\Data $helper,
        \Webkul\MpZoom\Helper\Data $zoomHelper,
        \Webkul\MpStripe\Helper\Data $stripeHelper,
        ProductRepositoryInterface $productRepository,
        \Webkul\MpAdvancedBookingSystem\Helper\Data $bookingHelper,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone
    ) {
        $this->timezone = $timezone;
        $this->zoomHelper = $zoomHelper;
        $this->stripeHelper = $stripeHelper;
        $this->_bookingHelper = $bookingHelper;
        $this->_productRepository = $productRepository;
    }

    /**
     * Sales Order Invoice Save After event handler.
     *
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $event = $observer->getInvoice();
        $invoiceId = $observer->getInvoice()->getId();
        $order = $observer->getInvoice()->getOrder();
        $lastOrderId = $order->getId();

        foreach ($order->getAllItems() as $item) {
            $bookingDate = '';
            $bookingTime = '';

            // Custom Slot Product
            $helper = $this->_bookingHelper;
            $customAttrSetId = $helper->getProductAttributeSetIdByLabel(
                'Custom Slot Product'
            );
            $product = $this->_productRepository->getById($item->getProductId());
            $paymentAction = $this->stripeHelper->getConfigValue('stripe_payment_action');

            $stripeIntent = $order->getStripePaymentIntent();
            $paymentCode = $order->getPayment()->getMethod();
            $meeting = true;

            if ($paymentCode == PaymentMethod::METHOD_CODE && $stripeIntent != "") {
                $meeting = false;
            }

            if ($item->getProductType() == 'booking' && $customAttrSetId != $product->getAttributeSetId() && $meeting
            ) {
                $buyInfo = $item->getProductOptions()['info_buyRequest'];
                if (isset($buyInfo['booking_date']) && isset($buyInfo['booking_time'])) {
                    $bookingDate = $buyInfo['booking_date'];
                    $bookingTime = $buyInfo['booking_time'];
                } else {
                    $i = 0;
                    foreach ($buyInfo['options'] as $optionVal) {
                        if ($i == 0) {
                            $bookingDate = $optionVal;
                        } else {
                            $bookingTime = $optionVal;
                        }
                        $i++;
                        
                    } 
                }
                
                $date = date_create($bookingDate);
                $bookingDate = date_format($date, "Y-m-d");
                $bookingTime = date("H:i:s", strtotime($bookingTime));
                $timezone = $this->zoomHelper->getTimezone($item);
                $meetingData = [
                    "topic"=> $item->getName(),
                    "type"=> "2",
                    "start_time"=> $bookingDate."T".$bookingTime,
                    "duration"=> $product->getSlotDuration(),
                    "timezone"=> $timezone,
                    "password"=> $this->zoomHelper->generateRandomPwd(),
                    "agenda"=> $item->getName()
                ];
                $zoomUserEmail = $this->zoomHelper->isZoomUserExist($item->getProductId());
                if ($zoomUserEmail) {
                    $userId = $zoomUserEmail;
                } else {
                    // $newZoomUserEmail = $this->zoomHelper->createZoomUser($item->getProductId());
                    throw new \Magento\Framework\Exception\LocalizedException(
                        __('Please create a zoom user to create Invoice')
                    );
                    // $userId = $newZoomUserEmail;
                }
                $meetingInfo = $this->zoomHelper->createZoomMeeting($meetingData, $userId);
                $this->zoomHelper->saveMeetingDetails(
                    $meetingInfo,
                    $order->getId(),
                    $item->getProductId(),
                    $item->getItemId()
                );
                $this->zoomHelper->sendCustomerMail($meetingInfo, $item->getProductId(), $order);
                $this->zoomHelper->sendHostMail($meetingInfo, $item->getProductId(), $order);
            }
        }
    }
}
