<?php

namespace Webkul\MpZoom\Observer;

use Magento\Framework\Event\ObserverInterface;

class SellerRegister implements ObserverInterface
{

    public $helperData;
    public $messageManager;
    protected $_customerRepositoryInterface;

    public function __construct(
        \Webkul\MpZoom\Helper\Data $helperData,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface
    ) {
        $this->helperData = $helperData;
        $this->messageManager = $messageManager;
        $this->_customerRepositoryInterface = $customerRepositoryInterface;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        // die("test");
        $helper = $this->helperData;
        $data = $observer['account_controller'];
        $paramData = $data->getRequest()->getParams();
        try {
            if (!empty($paramData['is_seller']) && !empty($paramData['profileurl']) && $paramData['is_seller'] == 1) {
                $customer = $observer->getCustomer();
                $customerId = $customer->getId();
                $result = $helper->createZoomUser($customerId);
                $this->messageManager->addSuccess(__('Zoom Account Created Successfully. Please activate zoom account with the link on your mail'));
    
            }
        } catch (\Exception $e) {
            // print_r($e->getMessage());die;
            $this->messageManager->addError($e->getMessage());
        }
        
    }
}