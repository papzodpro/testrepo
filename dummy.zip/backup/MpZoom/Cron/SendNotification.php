<?php
/**
 * Webkul Software.
 *
 * @category   Webkul
 * @package    Webkul_MpZoom
 * @author     Webkul
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */

namespace Webkul\MpZoom\Cron;

use Magento\Store\Model\StoreManagerInterface;
use Webkul\PushNotification\Model\ResourceModel\UsersToken\CollectionFactory as UsertokenCollectionFactory;
use Webkul\MobikulCore\Model\ResourceModel\DeviceToken\CollectionFactory as DeviceTokenCollectionFactory;

/**
 * Cron class.
 */
class SendNotification
{
    /**
     * @var \Webkul\MpZoom\Model\PaymentCapture
     */
    public $capture;
    public $bookingHelper;
    public $orderFactory;
    /**
     * @var \Webkul\PushNotification\Helper\Data
     */
    public $helper;
    public $logger;
    public $storemanager;
    public $usersToken;
    public $deviceToken;
    public $zoomHelper;
    public $mobikulcoreHelper;
    public $curl;
    public $mpHelper;
    public $collectionFactory;
    private const PATH = 'pushnotification/';

    private const CHROME = 'Chrome';

    private const FIREFOX = 'Firefox';

    /**
     * __construct function
     *
     * @param \Webkul\MpZoom\Model\PaymentCapture $capture
     * @param \Webkul\MpAdvancedBookingSystem\Helper\Data $bookingHelper
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param \Webkul\PushNotification\Helper\Data $helper
     * @param \Psr\Log\LoggerInterface $logger
     * @param StoreManagerInterface $storemanager
     * @param UsertokenCollectionFactory $usersToken
     * @param DeviceTokenCollectionFactory $deviceToken
     * @param \Webkul\MpZoom\Helper\Data $zoomHelper
     * @param \Webkul\MobikulCore\Helper\Data $mobikulcoreHelper
     * @param \Magento\Framework\HTTP\Client\Curl $curl
     * @param \Webkul\MpZoom\Model\ResourceModel\MeetingInfo\CollectionFactory $collectionFactory
     */
    public function __construct(
        \Webkul\MpZoom\Model\PaymentCapture $capture,
        \Webkul\MpAdvancedBookingSystem\Helper\Data $bookingHelper,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Webkul\PushNotification\Helper\Data $helper,
        \Psr\Log\LoggerInterface $logger,
        StoreManagerInterface $storemanager,
        UsertokenCollectionFactory $usersToken,
        DeviceTokenCollectionFactory $deviceToken,
        \Webkul\MpZoom\Helper\Data $zoomHelper,
        \Webkul\MobikulCore\Helper\Data $mobikulcoreHelper,
        \Magento\Framework\HTTP\Client\Curl $curl,
        \Webkul\Marketplace\Helper\Data $mpHelper,
        \Webkul\MpZoom\Model\ResourceModel\MeetingInfo\CollectionFactory $collectionFactory
    ) {
        $this->capture = $capture;
        $this->bookingHelper = $bookingHelper;
        $this->orderFactory = $orderFactory;
        $this->helper = $helper;
        $this->logger = $logger;
        $this->storemanager = $storemanager;
        $this->usersToken = $usersToken->create();
        $this->deviceToken = $deviceToken->create();
        $this->zoomHelper = $zoomHelper;
        $this->mobikulcoreHelper = $mobikulcoreHelper;
        $this->curl = $curl;
        $this->mpHelper = $mpHelper;
        $this->collectionFactory = $collectionFactory;
    }

    /**
     * Execute Cron
     *
     * @return void
     */
    public function execute()
    {
        $meetingInfoColl = $this->collectionFactory->create()->addFieldToFilter('meeting_status', 1);
        foreach ($meetingInfoColl as $meetingInfo) {
            $orderId = $meetingInfo->getOrderId();
            $this->logger->info('Cron Started: '.$orderId);
            $order = $this->orderFactory->create()->load($orderId);
            $sellerId = $this->mpHelper->getSellerIdByProductId($meetingInfo->getProductId());
            $timeZone = $this->bookingHelper->getSellerTimeZone($sellerId);
            $endTime = date("m/d/Y H:i:s", strtotime('-5 minutes', strtotime($meetingInfo->getEndTime())));
            $this->logger->info('Meeting endTime: '.$endTime);
            $currentTime = date("Y-m-d H:i:s", $this->bookingHelper->getCurrentTimeAccrToTimezone($timeZone));
            $currentTime = $this->bookingHelper->convertAuctionTimeToTz($currentTime, $timeZone);
            
            /* Time Calculation*/
            $notifyEndTime = date("m/d/Y H:i:s", strtotime('+6 minutes', strtotime($endTime)));
            $dateTimeObject1 = date_create($currentTime);
            $dateTimeObject2 = date_create($notifyEndTime);
            $interval = date_diff($dateTimeObject1, $dateTimeObject2); 
            $min = $interval->days * 24 * 60;
            $min += $interval->h * 60;
            $min += $interval->i;
            if ($endTime != "" && (strtotime($endTime) <= strtotime($currentTime))) {
                $customerId = $order->getCustomerId();
                if ($customerId && $customerId != null) {
                    $ids = [$customerId, $sellerId];
                    $userTokenColl = $this->usersToken->addFieldToFilter('customer_id', ["in" => $ids]);
                    // $this->sendNotificationToMobile($customerId, $orderId, $min);
                    // $this->sendNotificationToMobile($sellerId, $orderId, $min);
                    foreach ($userTokenColl as $userToken) {
                        $url = $this->storemanager->getStore()->getBaseUrl()."/mpzoom/meeting/sendpushnotification/?";
                        $params = 'browser='.$userToken->getBrowser().'&token='.$userToken->getToken().'&time='.$min;
                        $this->curl->get($url.$params);
                    }
                }
            }

            $endTime = $meetingInfo->getEndTime();
            if ($endTime != "" && strtotime($currentTime) >= strtotime($endTime)) {
                $data = [
                    'action' => 'end'
                ];
                $meetingId = $meetingInfo->getMeetingId();
                $this->logger->info('Meeting End');
                $this->zoomHelper->endMeeting($data, $meetingId);
                // $this->capture->paymentCapture($orderId);
            }
        }
    }

    /**
     * SendNotificationToMobile function
     *
     * @param int $customerId
     * @param int $orderId
     * @return void
     */
    protected function sendNotificationToMobile($customerId, $orderId, $min)
    {
        try {
            $deviceTokenColl = $this->deviceToken->addFieldToFilter('customer_id', $customerId);
            $authKey = $this->mobikulcoreHelper->getConfigData("mobikul/notification/apikey");
            $androidTopic = $this->mobikulcoreHelper->getConfigData("mobikul/notification/andoridtopic");
            $iosTopic = $this->mobikulcoreHelper->getConfigData("mobikul/notification/iostopic");
            foreach ($deviceTokenColl as $deviceToken) {
                $message = [
                    "id" => $orderId,
                    "body" => __('The Meeting is about to end in %1 min', $min),
                    "title" => __("Zoom Meeting End!!"),
                    "sound" => "default",
                    "message" => __('The Meeting is about to end in %1 min', $min),
                    "notificationType" => "order"
                ];

                $url = "https://fcm.googleapis.com/fcm/send";
                $authKey = $this->mobikulcoreHelper->getConfigData("mobikul/notification/apikey");
                $headers = [
                    "Authorization" => "key=".$authKey,
                    "Content-Type" => "application/json"
                ];
                $fields = [
                    "to" => $deviceToken->getToken(),
                    "data" => $message,
                    "priority" => "high",
                    "time_to_live" => 30,
                    "delay_while_idle" => true,
                    "content_available" => true
                ];
                if ($deviceToken->getOs() == "ios") {
                    $fields["notification"] = $message;
                }
                $this->curl->setHeaders($headers);
                $this->curl->post($url, json_encode($fields));
                $result = $this->curl->getBody();
            }
        } catch (\Exception $e) {
            $this->logger->info("Zoom Cron".$e->getMessage());
        }
    }
}
