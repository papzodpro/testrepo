<?php
/**
 * Webkul Software.
 *
 * @category Webkul
 * @package Webkul_MpZoom
 * @author Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license https://store.webkul.com/license.html
 */


namespace Webkul\MpZoom\Api;

/**
 * MeetingInfoRepository Interface
 */
interface MeetingInfoRepositoryInterface
{

    /**
     * get by id
     *
     * @param int $id
     * @return \Webkul\MpZoom\Model\MeetingInfo
     */
    public function getById($id);
    /**
     * get by id
     *
     * @param int $id
     * @return \Webkul\MpZoom\Model\MeetingInfo
     */
    public function save(\Webkul\MpZoom\Model\MeetingInfo $subject);
    /**
     * get list
     *
     * @param Magento\Framework\Api\SearchCriteriaInterface $creteria
     * @return Magento\Framework\Api\SearchResults
     */
    public function getList();
    /**
     * delete
     *
     * @param \Webkul\MpZoom\Model\MeetingInfo $subject
     * @return boolean
     */
    public function delete(\Webkul\MpZoom\Model\MeetingInfo $subject);
    /**
     * delete by id
     *
     * @param int $id
     * @return boolean
     */
    public function deleteById($id);

}

