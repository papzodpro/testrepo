<?php
/**
 * Webkul Software.
 *
 * @category Webkul
 * @package Webkul_MpZoom
 * @author Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license https://store.webkul.com/license.html
 */


namespace Webkul\MpZoom\Api\Data;

/**
 * ConfigData Interface
 */
interface ConfigDataInterface
{

    public const ENTITY_ID = 'entity_id';

    public const SELLER_ID = 'seller_id';

    public const API_KEY = 'api_key';

    public const API_SECRET = 'api_secret';

    /**
     * Set EntityId
     *
     * @param int $entityId
     * @return Webkul\MpZoom\Api\Data\ConfigDataInterface
     */
    public function setEntityId($entityId);
    /**
     * Get EntityId
     *
     * @return int
     */
    public function getEntityId();
    /**
     * Set SellerId
     *
     * @param int $sellerId
     * @return Webkul\MpZoom\Api\Data\ConfigDataInterface
     */
    public function setSellerId($sellerId);
    /**
     * Get SellerId
     *
     * @return int
     */
    public function getSellerId();
    /**
     * Set ApiKey
     *
     * @param string $apiKey
     * @return Webkul\MpZoom\Api\Data\ConfigDataInterface
     */
    public function setApiKey($apiKey);
    /**
     * Get ApiKey
     *
     * @return string
     */
    public function getApiKey();
    /**
     * Set ApiSecret
     *
     * @param string $apiSecret
     * @return Webkul\MpZoom\Api\Data\ConfigDataInterface
     */
    public function setApiSecret($apiSecret);
    /**
     * Get ApiSecret
     *
     * @return string
     */
    public function getApiSecret();

}

