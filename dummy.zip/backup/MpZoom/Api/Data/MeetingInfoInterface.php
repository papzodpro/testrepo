<?php
/**
 * Webkul Software.
 *
 * @category Webkul
 * @package Webkul_MpZoom
 * @author Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license https://store.webkul.com/license.html
 */


namespace Webkul\MpZoom\Api\Data;

/**
 * MeetingInfo Interface
 */
interface MeetingInfoInterface
{

    public const ENTITY_ID = 'entity_id';

    public const MEETING_ID = 'meeting_id';

    public const ORDER_ID = 'order_id';

    public const PRODUCT_ID = 'product_id';

    public const START_URL = 'start_url';

    public const JOINING_URL = 'joining_url';

    public const INFO = 'info';

    /**
     * Set EntityId
     *
     * @param int $entityId
     * @return Webkul\MpZoom\Api\Data\MeetingInfoInterface
     */
    public function setEntityId($entityId);
    /**
     * Get EntityId
     *
     * @return int
     */
    public function getEntityId();
    /**
     * Set MeetingId
     *
     * @param int $meetingId
     * @return Webkul\MpZoom\Api\Data\MeetingInfoInterface
     */
    public function setMeetingId($meetingId);
    /**
     * Get MeetingId
     *
     * @return int
     */
    public function getMeetingId();
    /**
     * Set OrderId
     *
     * @param int $orderId
     * @return Webkul\MpZoom\Api\Data\MeetingInfoInterface
     */
    public function setOrderId($orderId);
    /**
     * Get OrderId
     *
     * @return int
     */
    public function getOrderId();
    /**
     * Set ProductId
     *
     * @param int $productId
     * @return Webkul\MpZoom\Api\Data\MeetingInfoInterface
     */
    public function setProductId($productId);
    /**
     * Get ProductId
     *
     * @return int
     */
    public function getProductId();
    /**
     * Set StartUrl
     *
     * @param string $startUrl
     * @return Webkul\MpZoom\Api\Data\MeetingInfoInterface
     */
    public function setStartUrl($startUrl);
    /**
     * Get StartUrl
     *
     * @return string
     */
    public function getStartUrl();
    /**
     * Set JoiningUrl
     *
     * @param string $joiningUrl
     * @return Webkul\MpZoom\Api\Data\MeetingInfoInterface
     */
    public function setJoiningUrl($joiningUrl);
    /**
     * Get JoiningUrl
     *
     * @return string
     */
    public function getJoiningUrl();
    /**
     * Set Info
     *
     * @param string $info
     * @return Webkul\MpZoom\Api\Data\MeetingInfoInterface
     */
    public function setInfo($info);
    /**
     * Get Info
     *
     * @return string
     */
    public function getInfo();

}

