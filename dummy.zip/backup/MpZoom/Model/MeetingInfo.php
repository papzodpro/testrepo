<?php
/**
 * Webkul Software.
 *
 * @category Webkul
 * @package Webkul_MpZoom
 * @author Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license https://store.webkul.com/license.html
 */


namespace Webkul\MpZoom\Model;

/**
 * MeetingInfo Class
 */
class MeetingInfo extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface, \Webkul\MpZoom\Api\Data\MeetingInfoInterface
{

    public const NOROUTE_ENTITY_ID = 'no-route';

    public const CACHE_TAG = 'webkul_mpzoom_meetinginfo';

    protected $_cacheTag = 'webkul_mpzoom_meetinginfo';

    protected $_eventPrefix = 'webkul_mpzoom_meetinginfo';

    /**
     * set resource model
     */
    public function _construct()
    {
        $this->_init(\Webkul\MpZoom\Model\ResourceModel\MeetingInfo::class);
    }

    /**
     * Load No-Route Indexer.
     *
     * @return $this
     */
    public function noRouteReasons()
    {
        return $this->load(self::NOROUTE_ENTITY_ID, $this->getIdFieldName());
    }

    /**
     * Get identities.
     *
     * @return []
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG.'_'.$this->getId()];
    }

    /**
     * Set EntityId
     *
     * @param int $entityId
     * @return Webkul\MpZoom\Model\MeetingInfoInterface
     */
    public function setEntityId($entityId)
    {
        return $this->setData(self::ENTITY_ID, $entityId);
    }

    /**
     * Get EntityId
     *
     * @return int
     */
    public function getEntityId()
    {
        return parent::getData(self::ENTITY_ID);
    }

    /**
     * Set MeetingId
     *
     * @param int $meetingId
     * @return Webkul\MpZoom\Model\MeetingInfoInterface
     */
    public function setMeetingId($meetingId)
    {
        return $this->setData(self::MEETING_ID, $meetingId);
    }

    /**
     * Get MeetingId
     *
     * @return int
     */
    public function getMeetingId()
    {
        return parent::getData(self::MEETING_ID);
    }

    /**
     * Set OrderId
     *
     * @param int $orderId
     * @return Webkul\MpZoom\Model\MeetingInfoInterface
     */
    public function setOrderId($orderId)
    {
        return $this->setData(self::ORDER_ID, $orderId);
    }

    /**
     * Get OrderId
     *
     * @return int
     */
    public function getOrderId()
    {
        return parent::getData(self::ORDER_ID);
    }

    /**
     * Set ProductId
     *
     * @param int $productId
     * @return Webkul\MpZoom\Model\MeetingInfoInterface
     */
    public function setProductId($productId)
    {
        return $this->setData(self::PRODUCT_ID, $productId);
    }

    /**
     * Get ProductId
     *
     * @return int
     */
    public function getProductId()
    {
        return parent::getData(self::PRODUCT_ID);
    }

    /**
     * Set StartUrl
     *
     * @param string $startUrl
     * @return Webkul\MpZoom\Model\MeetingInfoInterface
     */
    public function setStartUrl($startUrl)
    {
        return $this->setData(self::START_URL, $startUrl);
    }

    /**
     * Get StartUrl
     *
     * @return string
     */
    public function getStartUrl()
    {
        return parent::getData(self::START_URL);
    }

    /**
     * Set JoiningUrl
     *
     * @param string $joiningUrl
     * @return Webkul\MpZoom\Model\MeetingInfoInterface
     */
    public function setJoiningUrl($joiningUrl)
    {
        return $this->setData(self::JOINING_URL, $joiningUrl);
    }

    /**
     * Get JoiningUrl
     *
     * @return string
     */
    public function getJoiningUrl()
    {
        return parent::getData(self::JOINING_URL);
    }

    /**
     * Set Info
     *
     * @param string $info
     * @return Webkul\MpZoom\Model\MeetingInfoInterface
     */
    public function setInfo($info)
    {
        return $this->setData(self::INFO, $info);
    }

    /**
     * Get Info
     *
     * @return string
     */
    public function getInfo()
    {
        return parent::getData(self::INFO);
    }


}

