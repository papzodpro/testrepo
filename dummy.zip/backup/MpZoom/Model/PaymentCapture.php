<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoom
 * @author    Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpZoom\Model;

use Magento\Customer\Model\Session;
use Webkul\MpStripe\Controller\Payment\CreateIntent;

class PaymentCapture
{
    public $_logger;
    public $sellerKeys;
    /**
     * @var \Webkul\MpStripe\Controller\Payment\CreateIntent
     */
    public $createIntent;
    public $orderRepository;
    /**
     * @var \Magento\Customer\Model\Session
     */
    private $customerSession;

    /**
     * @var \Webkul\MpStripe\Helper\Data
     */
    private $helper;

    /**
     * @var \Webkul\Marketplace\Helper\Data
     */
    private $marketplaceHelper;

    /**
     * Undocumented function
     *
     * @param Session $customerSession
     * @param CreateIntent $createIntent
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Webkul\MpStripe\Helper\Data $helper
     * @param \Webkul\Marketplace\Helper\Data $marketplaceHelper
     * @param \Magento\Sales\Model\OrderRepository $orderRepository
     * @param \Webkul\MpStripe\Model\StripeSellerRepository $sellerKeys
     */
    public function __construct(
        Session $customerSession,
        CreateIntent $createIntent,
        \Psr\Log\LoggerInterface $logger,
        \Webkul\MpStripe\Helper\Data $helper,
        \Webkul\Marketplace\Helper\Data $marketplaceHelper,
        \Magento\Sales\Model\OrderRepository $orderRepository,
        \Webkul\MpStripe\Model\StripeSellerRepository $sellerKeys
    ) {
        $this->helper = $helper;
        $this->_logger = $logger;
        $this->sellerKeys = $sellerKeys;
        $this->createIntent = $createIntent;
        $this->customerSession = $customerSession;
        $this->orderRepository = $orderRepository;
        $this->marketplaceHelper = $marketplaceHelper;
    }

    /**
     * Payment Capture
     *
     * @param int $orderId
     */
    public function paymentCapture($orderId)
    {
        $order = $this->orderRepository->get($orderId);
        if (!$order->canInvoice()) {
            $this->_logger->info(__('The order has already been captured successfully'));
            return false;
        }
        $paymentIntent = $order->getStripePaymentIntent();
        if ($paymentIntent == "") {
            $this->_logger->info(__('The order has not place through stripe payment.'));
            return false;
        }
        $orderItems = $order->getAllItems();
        $productId = "";
        foreach ($orderItems as $item) {
            $productId = $item->getProductId();
            break;
        }
        $sellerId = $this->marketplaceHelper->getSellerIdByProductId($productId);
        $this->helper->setUpDefaultDetails();
        $finalCart = $this->helper->getFinalCart($order);
        $finalCartData = $this->helper->getCheckoutFinalData($finalCart, $order);
        $ifSellerInCart = $this->helper->getIfSellerInCart($finalCartData);
        try {
            if ($sellerId != 0 && $this->helper->isDirectCharge()) {
                $collectionData = $this->sellerKeys->getBySellerId($sellerId);
                $paymentIntent = \Stripe\PaymentIntent::retrieve(
                    $paymentIntent,
                    ['stripe_account' => $collectionData["stripe_user_id"]]
                );
            } else {
                $this->_logger->info("Payment");
                $paymentIntent = \Stripe\PaymentIntent::retrieve(
                    $paymentIntent
                );
            }
            $captureData = $paymentIntent->capture();
            $response = [];
            if ($ifSellerInCart && !$this->helper->isDirectCharge()) {
                foreach ($finalCartData as $sellerId => $paymentDetail) {
                    if (!empty($paymentDetail['cart']['stripe_user_id'])) {
                        $response[$sellerId] = $this->createIntent->createStripeTransferCharge(
                            $paymentDetail,
                            $paymentIntent['charges']['data'][0]
                        );
                    }
                }
            }
            $this->_logger->info(__('Order captured successfully, invoices will be generated automatically'));
        } catch (\Exception $e) {
            $this->_logger->error("paymentIntent: ".$paymentIntent);
            $this->_logger->error('capture zoom payment: '.$e->getMessage());
        }
    }
}
