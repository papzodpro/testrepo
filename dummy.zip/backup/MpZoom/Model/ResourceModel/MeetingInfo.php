<?php
/**
 * Webkul Software.
 *
 * @category Webkul
 * @package Webkul_MpZoom
 * @author Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license https://store.webkul.com/license.html
 */


namespace Webkul\MpZoom\Model\ResourceModel;

/**
 * MeetingInfo Class
 */
class MeetingInfo extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{

    /**
     * Initialize resource model
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init("wk_mpzoom_meeting_info", "entity_id");
    }


}

