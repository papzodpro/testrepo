<?php
/**
 * Webkul Software.
 *
 * @category     Webkul
 * @package      Webkul_MpZoom
 * @author       Webkul
 * @copyright    Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license      https://store.webkul.com/license.html
 */


namespace Webkul\MpZoom\Model;

class MeetingInfoRepository implements \Webkul\MpZoom\Api\MeetingInfoRepositoryInterface
{

    protected $modelFactory = null;

    protected $collectionFactory = null;

    /**
     * initialize
     *
     * @param \Webkul\MpZoom\Model\MeetingInfoFactory $modelFactory
     * @param \Webkul\MpZoom\Model\ResourceModel\MeetingInfo\CollectionFactory
     * $collectionFactory
     * @return void
     */
    public function __construct(\Webkul\MpZoom\Model\MeetingInfoFactory $modelFactory, \Webkul\MpZoom\Model\ResourceModel\MeetingInfo\CollectionFactory $collectionFactory)
    {
        $this->modelFactory = $modelFactory;
        $this->collectionFactory = $collectionFactory;
    }

    /**
     * get by id
     *
     * @param int $id
     * @return \Webkul\MpZoom\Model\MeetingInfo
     */
    public function getById($id)
    {
        $model = $this->modelFactory->create()->load($id);
        if (!$model->getId()) {
            throw new \Magento\Framework\Exception\NoSuchEntityException(__('The CMS block with the "%1" ID doesn\'t exist.', $id));
        }
        return $model;
    }

    /**
     * get by id
     *
     * @param int $id
     * @return \Webkul\MpZoom\Model\MeetingInfo
     */
    public function save(\Webkul\MpZoom\Model\MeetingInfo $subject)
    {
        try {
            $subject->save();
        } catch (\Exception $exception) {
            throw new \Magento\Framework\Exception\CouldNotSaveException(__($exception->getMessage())); 
        }
        return $subject;
    }

    /**
     * get list
     *
     * @return void
     */
    public function getList()
    {
        $collection = $this->collectionFactory->create();
        return $collection;
    }

    /**
     * delete
     *
     * @param \Webkul\MpZoom\Model\MeetingInfo $subject
     * @return boolean
     */
    public function delete(\Webkul\MpZoom\Model\MeetingInfo $subject)
    {
        try {
            $subject->delete();
        } catch (\Exception $exception) {
            throw new \Magento\Framework\Exception\CouldNotDeleteException(__($exception->getMessage()));
        }
        return true;
    }

    /**
     * delete by id
     *
     * @param int $id
     * @return boolean
     */
    public function deleteById($id)
    {
        return $this->delete($this->getById($id));
    }
}
