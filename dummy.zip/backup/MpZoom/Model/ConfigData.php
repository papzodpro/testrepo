<?php
/**
 * Webkul Software.
 *
 * @category Webkul
 * @package Webkul_MpZoom
 * @author Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license https://store.webkul.com/license.html
 */


namespace Webkul\MpZoom\Model;

/**
 * ConfigData Class
 */
class ConfigData extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface, \Webkul\MpZoom\Api\Data\ConfigDataInterface
{

    public const NOROUTE_ENTITY_ID = 'no-route';

    public const CACHE_TAG = 'webkul_mpzoom_configdata';

    protected $_cacheTag = 'webkul_mpzoom_configdata';

    protected $_eventPrefix = 'webkul_mpzoom_configdata';

    /**
     * set resource model
     */
    public function _construct()
    {
        $this->_init(\Webkul\MpZoom\Model\ResourceModel\ConfigData::class);
    }

    /**
     * Load No-Route Indexer.
     *
     * @return $this
     */
    public function noRouteReasons()
    {
        return $this->load(self::NOROUTE_ENTITY_ID, $this->getIdFieldName());
    }

    /**
     * Get identities.
     *
     * @return []
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG.'_'.$this->getId()];
    }

    /**
     * Set EntityId
     *
     * @param int $entityId
     * @return Webkul\MpZoom\Model\ConfigDataInterface
     */
    public function setEntityId($entityId)
    {
        return $this->setData(self::ENTITY_ID, $entityId);
    }

    /**
     * Get EntityId
     *
     * @return int
     */
    public function getEntityId()
    {
        return parent::getData(self::ENTITY_ID);
    }

    /**
     * Set SellerId
     *
     * @param int $sellerId
     * @return Webkul\MpZoom\Model\ConfigDataInterface
     */
    public function setSellerId($sellerId)
    {
        return $this->setData(self::SELLER_ID, $sellerId);
    }

    /**
     * Get SellerId
     *
     * @return int
     */
    public function getSellerId()
    {
        return parent::getData(self::SELLER_ID);
    }

    /**
     * Set ApiKey
     *
     * @param string $apiKey
     * @return Webkul\MpZoom\Model\ConfigDataInterface
     */
    public function setApiKey($apiKey)
    {
        return $this->setData(self::API_KEY, $apiKey);
    }

    /**
     * Get ApiKey
     *
     * @return string
     */
    public function getApiKey()
    {
        return parent::getData(self::API_KEY);
    }

    /**
     * Set ApiSecret
     *
     * @param string $apiSecret
     * @return Webkul\MpZoom\Model\ConfigDataInterface
     */
    public function setApiSecret($apiSecret)
    {
        return $this->setData(self::API_SECRET, $apiSecret);
    }

    /**
     * Get ApiSecret
     *
     * @return string
     */
    public function getApiSecret()
    {
        return parent::getData(self::API_SECRET);
    }


}

