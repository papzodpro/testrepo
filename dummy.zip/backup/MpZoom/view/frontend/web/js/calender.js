/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoom
 * @author    Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
 define([
    "jquery",
    "mage/calendar",
    "Webkul_MpZoom/js/calender/main"
], function ($) {
    'use strict';
    $.widget('calenderdashboard.calenderdashboard',
        {
            _create: function () {
                var self = this;
                var calendarEl = document.getElementById('calendar-dashboard');
                var calendar = new FullCalendar.Calendar(calendarEl, {
                    headerToolbar: {
                        left: 'prevYear,prev,next,nextYear today',
                        center: 'title',
                        right: 'dayGridMonth,dayGridWeek,dayGridDay'
                    },
                    initialDate: self.options.intialDate,
                    navLinks: true, // can click day/week names to navigate views
                    editable: false,
                    dayMaxEvents: true, // allow "more" link when too many events
                    views: {
                        timeGrid: {
                          dayMaxEventRows: 2 // adjust to 2 only for timeGridWeek/timeGridDay
                        }
                    },
                    eventSources: [
                        {
                            events: self.options.events,
                        },
                        {
                            events:self.options.unbookedEvents ,
                            color: 'rgb(84 11 131)',
                            textColor: 'white'
                        }
                    ]
                });
                calendar.render();
            }
        }
    );
    return $.calenderdashboard.calenderdashboard;
});
