<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoom
 * @author    Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpZoom\Controller\Meeting;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Store\Model\StoreManagerInterface;
use Webkul\PushNotification\Model\ResourceModel\UsersToken\CollectionFactory as UsertokenCollectionFactory;
use Webkul\MobikulCore\Model\ResourceModel\DeviceToken\CollectionFactory as DeviceTokenCollectionFactory;

class Test extends Action
{

    /**
     * @var \Webkul\MpAdvancedBookingSystem\Helper\Data
     */
    public $bookingHelper;
    public $orderFactory;
    public $helper;
    public $logger;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    public $storemanager;
    public $usersToken;
    public $deviceToken;
    /**
     * @var \Webkul\MpZoom\Helper\Data
     */
    public $zoomHelper;
    public $mobikulcoreHelper;
    public $curl;
    /**
     * @var \Webkul\Marketplace\Helper\Data
     */
    public $mpHelper;
    /**
     * @var \Webkul\MpZoom\Model\ResourceModel\MeetingInfo\CollectionFactory
     */
    public $collectionFactory;
    private const PATH = 'pushnotification/';

    private const CHROME = 'Chrome';

    private const FIREFOX = 'Firefox';
    /**
     * @var PageFactory
     */
    protected $_resultPageFactory;
    const CREATE_MEETING_URL = "https://api.zoom.us/v2/";

    /**
     * initialization
     *
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        \Webkul\MpAdvancedBookingSystem\Helper\Data $bookingHelper,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Webkul\PushNotification\Helper\Data $helper,
        \Psr\Log\LoggerInterface $logger,
        StoreManagerInterface $storemanager,
        UsertokenCollectionFactory $usersToken,
        DeviceTokenCollectionFactory $deviceToken,
        \Webkul\MpZoom\Helper\Data $zoomHelper,
        \Webkul\MobikulCore\Helper\Data $mobikulcoreHelper,
        \Magento\Framework\HTTP\Client\Curl $curl,
        \Webkul\Marketplace\Helper\Data $mpHelper,
        \Webkul\MpZoom\Model\ResourceModel\MeetingInfo\CollectionFactory $collectionFactory
    ) {
        $this->bookingHelper = $bookingHelper;
        $this->orderFactory = $orderFactory;
        $this->helper = $helper;
        $this->logger = $logger;
        $this->storemanager = $storemanager;
        $this->usersToken = $usersToken->create();
        $this->deviceToken = $deviceToken->create();
        $this->zoomHelper = $zoomHelper;
        $this->mobikulcoreHelper = $mobikulcoreHelper;
        $this->curl = $curl;
        $this->mpHelper = $mpHelper;
        $this->collectionFactory = $collectionFactory;
        parent::__construct($context);
    }
    
    public function execute()
    {
        $order = $this->orderFactory->create()->load($orderId);
        // $meetingInfoColl = $this->collectionFactory->create()->addFieldToFilter('meeting_status', 1);
        // foreach ($meetingInfoColl as $meetingInfo) {
        //     $orderId = $meetingInfo->getOrderId();
        //     $this->logger->info('Cron Started: '.$orderId);
        //     $order = $this->orderFactory->create()->load($orderId);
        //     $sellerId = $this->mpHelper->getSellerIdByProductId($meetingInfo->getProductId());
        //     $timeZone = $this->bookingHelper->getSellerTimeZone($sellerId);
        //     $endTime = date("m/d/Y H:i:s", strtotime('-5 minutes', strtotime($meetingInfo->getEndTime())));
        //     $this->logger->info('Meeting endTime: '.$endTime);
        //     $currentTime = date("Y-m-d H:i:s", $this->bookingHelper->getCurrentTimeAccrToTimezone($timeZone));
        //     $currentTime = $this->bookingHelper->convertAuctionTimeToTz($currentTime, $timeZone);
        //     // $currentTime = date("Y-m-d H:i:s", $this->bookingHelper->getCurrentTimeAccrToTimezone($timeZone));
        //     // $currentTime = $this->bookingHelper->convertAuctionTimeToTz($currentTime, $timeZone);

        //     /* Time Calculation*/
        //     $notifyEndTime = date("m/d/Y H:i:s", strtotime('+6 minutes', strtotime($endTime)));
        //     $dateTimeObject1 = date_create($currentTime);
        //     $dateTimeObject2 = date_create($notifyEndTime);
        //     $interval = date_diff($dateTimeObject1, $dateTimeObject2); 
        //     $min = $interval->days * 24 * 60;
        //     $min += $interval->h * 60;
        //     $min += $interval->i;
        //     echo $min;die;
        //     if ($endTime != "" && (strtotime($endTime) <= strtotime($currentTime))) {
        //         $customerId = $order->getCustomerId();
        //         if ($customerId && $customerId != null) {
        //             $ids = [607];
        //             $userTokenColl = $this->usersToken->addFieldToFilter('customer_id', ["in" => $ids]);
        //             foreach ($userTokenColl as $userToken) {
        //                 $this->notificationData($userToken, $min);
        //             }
        //             $this->sendNotificationToMobile($customerId, $orderId);
        //         }
        //     }die("END");

        //     $endTime = $meetingInfo->getEndTime();
        //     if ($endTime != "" && strtotime($currentTime) >= strtotime($endTime)) {
        //         $data = [
        //             'action' => 'end'
        //         ];
        //         $meetingId = $meetingInfo->getMeetingId();
        //         $this->logger->info('Meeting End');
        //         $this->zoomHelper->endMeeting($data, $meetingId);
        //         // $this->capture->paymentCapture($orderId);
        //     }
        // }die("end");
    }

    /**
     * NotificationData function
     *
     * @param [type] $userToken
     * @return void
     */
    protected function notificationData($userToken, $min)
    {
        $chrome = [];
        $mozila = [];
        $notificationData = [];
        $notification = [];
        $notificationData['title'] =  __('Zoom Meeting End!!');
        $notificationData['body'] = __('The meeting is about to end in %1 min.', $min);
        $notification['notification'] = $notificationData;
        if ($userToken->getBrowser() == self::CHROME) {
            $token = $userToken->getToken();
            $this->logger->info('send notification token: '.$token);
            $response = $this->helper->sendToChrome($token, $notification);
            $this->logger->info('send notification response: '.$response);
        } elseif ($userToken->getBrowser() == self::FIREFOX) {
            $response = $this->helper->sendToFirefox($userToken->getToken(), $notification);
        }
    }

    /**
     * SendNotificationToMobile function
     *
     * @param int $customerId
     * @param int $orderId
     * @return void
     */
    protected function sendNotificationToMobile($customerId, $orderId)
    {
        try {
            $deviceTokenColl = $this->deviceToken->addFieldToFilter('customer_id', $customerId);
            $authKey = $this->mobikulcoreHelper->getConfigData("mobikul/notification/apikey");
            $androidTopic = $this->mobikulcoreHelper->getConfigData("mobikul/notification/andoridtopic");
            $iosTopic = $this->mobikulcoreHelper->getConfigData("mobikul/notification/iostopic");
            foreach ($deviceTokenColl as $deviceToken) {
                $message = [
                    "id" => $orderId,
                    "body" => __('The Meeting is about to end in 5min'),
                    "title" => __("Zoom Meeting End!!"),
                    "sound" => "default",
                    "message" => __('The Meeting is about to end in 5min'),
                    "notificationType" => "order"
                ];

                $url = "https://fcm.googleapis.com/fcm/send";
                $authKey = $this->mobikulcoreHelper->getConfigData("mobikul/notification/apikey");
                $headers = [
                    "Authorization" => "key=".$authKey,
                    "Content-Type" => "application/json"
                ];
                $fields = [
                    "to" => $deviceToken->getToken(),
                    "data" => $message,
                    "priority" => "high",
                    "time_to_live" => 30,
                    "delay_while_idle" => true,
                    "content_available" => true
                ];
                if ($deviceToken->getOs() == "ios") {
                    $fields["notification"] = $message;
                }
                $this->curl->setHeaders($headers);
                $this->curl->post($url, json_encode($fields));
                $result = $this->curl->getBody();
            }
        } catch (\Exception $e) {
            $this->logger->info("Zoom Cron".$e->getMessage());
        }
    }

}