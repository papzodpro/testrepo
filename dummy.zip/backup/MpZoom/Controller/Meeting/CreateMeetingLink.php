<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoom
 * @author    Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpZoom\Controller\Meeting;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;

class CreateMeetingLink extends Action
{
    public $onePage;
    /**
     * @var \Webkul\Marketplace\Helper\Data
     */
    public $mpHelper;
    public $helperData;
    public $orderFactory;
    /**
     * @var JsonFactory
     */
    protected $resultJsonFactory;

    /**
     * __construct function
     *
     * @param Context $context
     * @param JsonFactory $resultJsonFactory
     * @param \Webkul\MpZoom\Helper\Data $helperData
     * @param \Webkul\Marketplace\Helper\Data $mpHelper
     * @param \Magento\Checkout\Model\Type\Onepage $onePage
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     */
    public function __construct(
        Context $context,
        JsonFactory $resultJsonFactory,
        \Webkul\MpZoom\Helper\Data $helperData,
        \Webkul\Marketplace\Helper\Data $mpHelper,
        \Magento\Checkout\Model\Type\Onepage $onePage,
        \Magento\Sales\Model\OrderFactory $orderFactory
    ) {
        $this->onePage = $onePage;
        $this->mpHelper = $mpHelper;
        $this->helperData = $helperData;
        $this->orderFactory = $orderFactory;
        $this->resultJsonFactory = $resultJsonFactory;
        parent::__construct($context);
    }
    
    /**
     * Create Meeting Link
     *
     * @return \Magento\Framework\Controller\Result\Json
     */
    public function execute()
    {
        $helper = $this->helperData;
        try {
            $intentId = $this->getRequest()->getParam('payment_intent_id');
            $orderId = $this->onePage->getCheckout()->getLastOrderId();
            $order = $this->orderFactory->create()->load($orderId);
            $result = $helper->craeteMeetingLink($order);
        } catch (\Exception $e) {
            $result = [
                "success" => false,
                'message' => __('Some Error Occurred!!'),
                "error_message" => $e->getMessage()
            ];
        }
        $resultJson = $this->resultJsonFactory->create();
        return $resultJson->setData($result);
    }
}
