<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoom
 * @author    Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpZoom\Controller\Meeting;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;

class SendPushNotification extends Action
{
    public $helper;
    public $logger;
    private const CHROME = 'Chrome';

    private const FIREFOX = 'Firefox';

    /**
     * __construct function
     *
     * @param Context $context
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Webkul\PushNotification\Helper\Data $helper
     */
    public function __construct(
        Context $context,
        \Psr\Log\LoggerInterface $logger,
        \Webkul\PushNotification\Helper\Data $helper
    ) {
        $this->helper = $helper;
        $this->logger = $logger;
        parent::__construct($context);
    }
    
    /**
     * Execute
     *
     * @return void
     */
    public function execute()
    {
        $notificationData = [];
        $notification = [];
        $data = $this->getRequest()->getParams();
        $notificationData['title'] =  __('Zoom Meeting End!!');
        if ($data['time'] == 0) {
            $notificationData['body'] = __('The meeting has completed.');
        } else {
            $notificationData['body'] = __('The meeting is about to end in %1 min.', $data['time']);
        }
        $notification['notification'] = $notificationData;
        if ($data['browser'] == self::CHROME) {
            $this->logger->info('send notification token: '.$data['token']);
            $response = $this->helper->sendToChrome($data['token'], $notification);
            $this->logger->info('send notification response: '.$response);
        } elseif ($data['browser'] == self::FIREFOX) {
            $response = $this->helper->sendToFirefox($data['token'], $notification);
        }   
    }
}