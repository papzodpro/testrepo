<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoom
 * @author    Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpZoom\Controller\Meeting;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class SaveConfig extends Action
{
    public $helperData;
    public $configDataFactory;
    /**
     * @var PageFactory
     */
    protected $_resultPageFactory;

    /**
     * initialization
     *
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        \Webkul\Marketplace\Helper\Data $helperData,
        \Webkul\MpZoom\Model\ConfigDataFactory $configDataFactory,
        PageFactory $resultPageFactory
    ) {
        $this->_resultPageFactory = $resultPageFactory;
        $this->helperData = $helperData;
        $this->configDataFactory = $configDataFactory;
        parent::__construct($context);
    }
    
    public function execute()
    {
        $helper = $this->helperData;
        $params = $this->getRequest()->getParams();
        $sellerId = $helper->getCustomerId();
        if ($params) {
            $model = $this->configDataFactory->create();
            $collection = $model->getCollection()->addFieldToFilter('seller_id', $sellerId);
            if ($collection->getSize()) {
                foreach ($collection as $data) {
                    $data->setApiKey($params['zoom_api_key']);
                    $data->setApiSecret($params['zoom_api_secret']);
                    $data->save();
                }
            } else {
                $model = $this->configDataFactory->create();
                $model->setSellerId($sellerId);
                $model->setApiKey($params['zoom_api_key']);
                $model->setApiSecret($params['zoom_api_secret']);
                $model->save();
            }
            return $this->resultRedirectFactory->create()->setPath(
                'mpzoom/meeting/setting',
                ['_secure' => $this->getRequest()->isSecure()]
            );
        }


    }
}