<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoom
 * @author    Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpZoom\Controller\Meeting;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\Result\JsonFactory;

class Create extends Action
{
    public $helperData;
    public $mpHelper;
    public $resultJsonFactory;
    /**
     * @var PageFactory
     */
    protected $_resultPageFactory;

    /**
     * initialization
     *
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        \Webkul\MpZoom\Helper\Data $helperData,
        \Webkul\Marketplace\Helper\Data $mpHelper,
        JsonFactory $resultJsonFactory,
        PageFactory $resultPageFactory
    ) {
        $this->_resultPageFactory = $resultPageFactory;
        $this->helperData = $helperData;
        $this->mpHelper = $mpHelper;
        $this->resultJsonFactory = $resultJsonFactory;
        parent::__construct($context);
    }
    
    public function execute()
    {
        $helper = $this->helperData;
        try {
            $sellerId = $this->mpHelper->getCustomerId();
            $result = $helper->createZoomUser($sellerId);

            $returnData = [
                'success' => true,
                'title' => __('Zoom Account Created Successfully'),
                'msg' => __('Please Activate your account from the mail in your inbox')
            ];
        } catch (\Exception $e) {
            $returnData = [
                "success" => false,
                'title' => __('Some Error Occurred!!'),
                'msg' => $e->getMessage(),
            ];
        }
        $resultJson = $this->resultJsonFactory->create();
        return $resultJson->setData($returnData);
    }
}
