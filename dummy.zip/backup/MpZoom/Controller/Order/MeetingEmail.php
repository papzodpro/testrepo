<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoom
 * @author    Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpZoom\Controller\Order;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class MeetingEmail extends Action
{
    public $orderFactory;
    public $helper;
    public $meetingInfo;
    /**
     * @var PageFactory
     */
    protected $_resultPageFactory;

    /**
     * construct
     *
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param \Webkul\MpZoom\Helper\Data $helper
     * @param \Webkul\MpZoom\ViewModel\MeetingInfo $meetingInfo
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Webkul\MpZoom\Helper\Data $helper,
        \Webkul\MpZoom\ViewModel\MeetingInfo $meetingInfo,
        PageFactory $resultPageFactory
    ) {
        $this->orderFactory = $orderFactory;
        $this->helper = $helper;
        $this->meetingInfo = $meetingInfo;
        $this->_resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }
    
    public function execute()
    {
        $orderId = $this->getRequest()->getParam('id');
        $order = $this->orderFactory->create()->load($orderId);
        if ($order) {
            foreach ($order->getAllItems() as $item) {
                if ($item->getProductType() == 'booking' && $item->getQtyInvoiced() > 0) {
                    $meetingData = $this->meetingInfo->getMeetingInfo($item->getItemId(), $orderId);
                    $this->helper->sendCustomerMail($meetingData->getInfo(), $item->getProductId(), $order);
                }
            }
            $this->messageManager->addSuccessMessage(__('You sent the meeting email.'));
            return $this->resultRedirectFactory->create()->setPath(
                'marketplace/order/view',
                [
                    'id' => $order->getEntityId()
                ]
            );
        }
        return $this->resultRedirectFactory->create()->setPath('marketplace/*/');
    }
}
