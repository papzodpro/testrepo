<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoom
 * @author    Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpZoom\Controller\Events;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use \Magento\Framework\App\CsrfAwareActionInterface;

class StartMeeting extends Action implements CsrfAwareActionInterface
{
    /**
     * @var \Webkul\MpZoom\Model\PaymentCapture
     */
    protected $capture;

    /**
     * @var \Magento\Sales\Model\OrderFactory
     */
    protected $orderFactory;

    /**
     * @var \Magento\Catalog\Model\Product
     */
    protected $product;

    /**
     * @var \Webkul\MpZoom\Helper\Data
     */
    protected $helper;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $logger;

    /**
     * @var \Webkul\MpAdvancedBookingSystem\Helper\Data
     */
    protected $bookingHelper;

    /**
     * @var \Webkul\MpZoom\Helper\Data
     */
    protected $zoomHelper;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $date;

    /**
     * @var \Webkul\Marketplace\Helper\Data
     */
    protected $mpHelper;

    /**
     * @var \Webkul\MpZoom\Model\ResourceModel\MeetingInfo\CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $jsonResultFactory;

    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $request;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * __construct function
     *
     * @param Context $context
     * @param \Webkul\MpZoom\Model\PaymentCapture $capture
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param \Magento\Catalog\Model\Product $product
     * @param \Webkul\MpZoom\Helper\Data $helper
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Webkul\MpAdvancedBookingSystem\Helper\Data $bookingHelper
     * @param \Webkul\MpZoom\Helper\Data $zoomHelper
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $date
     * @param \Webkul\Marketplace\Helper\Data $mpHelper
     * @param \Webkul\MpZoom\Model\ResourceModel\MeetingInfo\CollectionFactory $collectionFactory
     * @param \Magento\Framework\Controller\Result\JsonFactory $jsonResultFactory
     * @param \Magento\Framework\App\RequestInterface $request
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     */
    public function __construct(
        Context $context,
        \Webkul\MpZoom\Model\PaymentCapture $capture,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Catalog\Model\Product $product,
        \Webkul\MpZoom\Helper\Data $helper,
        \Psr\Log\LoggerInterface $logger,
        \Webkul\MpAdvancedBookingSystem\Helper\Data $bookingHelper,
        \Webkul\MpZoom\Helper\Data $zoomHelper,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        \Webkul\Marketplace\Helper\Data $mpHelper,
        \Webkul\MpZoom\Model\ResourceModel\MeetingInfo\CollectionFactory $collectionFactory,
        \Magento\Framework\Controller\Result\JsonFactory $jsonResultFactory,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        $this->capture = $capture;
        $this->mpHelper = $mpHelper;
        $this->orderFactory = $orderFactory;
        $this->product = $product;
        $this->helper = $helper;
        $this->logger = $logger;
        $this->bookingHelper = $bookingHelper;
        $this->zoomHelper = $zoomHelper;
        $this->date = $date;
        $this->collectionFactory = $collectionFactory;
        $this->jsonResultFactory = $jsonResultFactory;
        $this->request = $request;
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        parent::__construct($context);
    }
    /**
     * @inheritDoc
     */
    public function createCsrfValidationException(
        RequestInterface $request
    ): ?InvalidRequestException {
        return null;
    }

    /**
     * @inheritDoc
     */
    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }

    /**
     * Metting Event Handler
     *
     * @return void
     */
    public function execute()
    {
        $this->logger->info('webhook run');
        try {
            $body = file_get_contents('php://input');
            $params = json_decode($body, true);
            if ($params) {

                $secretToken = $this->scopeConfig->getValue(
                    "marketplace_zoom/general_settings/webhook_api_secret_key",
                    \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
                    $this->storeManager->getStore()->getStoreId()
                );

                $message = 'v0:'.$this->request->getHeader('x-zm-request-timestamp').':'.$body.'';
                
                $hashForVerify = hash_hmac("sha256", $message, $secretToken);

                $signature = 'v0='.$hashForVerify;
                
                if ($this->request->getHeader('x-zm-signature') === $signature) {
                    
                    if ($params['event'] == 'endpoint.url_validation') {

                        $plainToken = $params['payload']['plainToken'];

                        $hashmessage = hash_hmac("sha256", $plainToken, $secretToken);
                        
                        http_response_code(200);
                        
                        $result = $this->jsonResultFactory->create();

                        $result->setData(
                            [
                                "plainToken" => $plainToken,
                                "encryptedToken" => $hashmessage
                            ]
                        );
                        return $result;
                    } else {
                        $meetingId = $params['payload']['object']['id'];
                        $duration = $params['payload']['object']['duration'];
                        $meetingData = $this->getDataFromMeetingId($meetingId);
                        foreach ($meetingData as $data) {
                            $orderId = $data->getOrderId();
                            $product = $this->product->load($data->getProductId());
                            $productName = $product->getName();
                            $order = $this->orderFactory->create()->load($orderId);

                            $sellerId = $this->mpHelper->getSellerIdByProductId($data->getProductId());
                            $timeZone = $this->bookingHelper->getSellerTimeZone($sellerId);
                            $info = json_decode($data->getInfo(), true);
                            $meetingTime = $info['start_time'];
                            $time = new \DateTime($meetingTime, new \DateTimeZone('UTC'));
                            $time->setTimezone(new \DateTimeZone($info['timezone']));
                            if ($timeZone != $info['timezone']) {
                                $oldTime = $time->format('Y-m-d h:i A');
                                $time = new \DateTime($oldTime, new \DateTimeZone($info['timezone']));
                                $time->setTimezone(new \DateTimeZone($timeZone));
                            }
                            $startTime = $time->format('Y-m-d H:i:s');
                            $formattedDate = $time->format('Y-m-d H:i:s');
                            $endTime = date('Y-m-d H:i:s', strtotime('+'.$duration.' minutes', strtotime($formattedDate)));
                            if ($params['event'] == "meeting.started") {
                                if (!$data->getMeetingStatus()) {
                                    $data->setMeetingStatus(1);
                                    $data->setEndTime($endTime);
                                    $data->save();
                                }
                                $order->addStatusHistoryComment('Meeting has been started for '.$productName);
                            } elseif ($params['event'] == "meeting.ended") {
                                $data->setMeetingStatus(0);
                                $data->save();
                                $this->zoomHelper->deleteMeeting($meetingId);
                                $this->capture->paymentCapture($orderId);
                                $order->addStatusHistoryComment('Meeting has been ended for '.$productName);
                            }
                            $order->save();
                        }
                    }
                }
            }
        } catch (\Exception $e) {
            $this->logger->info('webhook exception '.$e->getMessage());
        }
    }

    /**
     * Get meeting data from meeting id
     *
     * @param string $id
     * @return void
     */
    public function getDataFromMeetingId($id)
    {
        $meetingInfoColl = $this->collectionFactory->create()->addFieldToFilter('meeting_id', $id);
        $data = $meetingInfoColl;
        return $data;
    }
}
