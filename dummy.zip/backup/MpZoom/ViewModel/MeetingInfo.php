<?php
/**
 * Webkul Software
 *
 * @category  Webkul
 * @package   Webkul_MpZoom
 * @author    Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */

namespace Webkul\MpZoom\ViewModel;

use Webkul\MpZoom\Model\ResourceModel\MeetingInfo\CollectionFactory;
use Webkul\Marketplace\Helper\Data as MpHelper;

class MeetingInfo implements \Magento\Framework\View\Element\Block\ArgumentInterface
{
    public $collectionFactory;
    public $orderFactory;
    public $bookingHelper;
    /**
     * @var SaleslistFactory
     */
    public $saleslistFactory;

    /**
     * @var MpHelper
     */
    public $mpHelper;

    /**
     * __construct function
     *
     * @param CollectionFactory $collectionFactory
     * @param MpHelper $mpHelper
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     */
    public function __construct(
        CollectionFactory $collectionFactory,
        MpHelper $mpHelper,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Webkul\MpAdvancedBookingSystem\Helper\Data $bookingHelper
    ) {
        $this->collectionFactory = $collectionFactory;
        $this->mpHelper = $mpHelper;
        $this->orderFactory = $orderFactory;
        $this->bookingHelper    = $bookingHelper;
    }

    /**
     * GetHostUrl function
     *
     * @param int $orderId
     * @param int $itemId
     * @return string
     */
    public function getHostUrl($orderId, $itemId)
    {
        $meetingCollection = $this->collectionFactory->create()
                                    ->addFieldToFilter('order_id', $orderId)
                                    ->addFieldToFilter('item_id', $itemId);
        $hostUrl = $meetingCollection->getFirstItem()->getStartUrl();
        return $hostUrl;
    }

    /**
     * GetJoiningUrl function
     *
     * @param int $orderId
     * @param int $itemId
     * @return string
     */
    public function getJoiningUrl($orderId, $itemId)
    {
        $meetingCollection = $this->collectionFactory->create()
                                    ->addFieldToFilter('order_id', $orderId)
                                    ->addFieldToFilter('item_id', $itemId);
        $joinUrl = $meetingCollection->getFirstItem()->getJoiningUrl();
        return $joinUrl;
    }

    /**
     * GetMeetingInfo function
     *
     * @param int $itemId
     * @param int $orderId
     * @return string
     */
    public function getMeetingInfo($itemId, $orderId)
    {
        $meetingCollection = $this->collectionFactory->create()
                                    ->addFieldToFilter('order_id', $orderId)
                                    ->addFieldToFilter('item_id', $itemId);
        return $meetingCollection->getFirstItem();
    }

    /**
     * Get Order
     *
     * @param int $orderId
     * @return \Magento\Sales\Model\Order
     */
    public function getOrder($orderId)
    {
        return $this->orderFactory->create()->load($orderId);
    }

    /**
     * Get Meeting End Time
     *
     * @param array $meetingInfo
     * @param int $productId
     * @return string
     */
    public function getMeetingEndTime($meetingInfo, $productId)
    {
        $sellerId = $this->mpHelper->getSellerIdByProductId($productId);
        $timeZone = $this->bookingHelper->getSellerTimeZone($sellerId);
        if ($timeZone == "") {
            $timeZone = "UTC";
        }
        $meetingTime = $meetingInfo['start_time'];
        $time = new \DateTime($meetingTime, new \DateTimeZone('UTC'));
        $time->setTimezone(new \DateTimeZone($meetingInfo['timezone']));
        if ($timeZone != $meetingInfo['timezone']) {
            $oldTime = $time->format('Y-m-d h:i A');
            $time = new \DateTime($oldTime, new \DateTimeZone($meetingInfo['timezone']));
            $time->setTimezone(new \DateTimeZone($timeZone));
        }
        $startTime = $time->format('Y-m-d H:i:s');
        $formattedDate = $time->format('Y-m-d H:i:s');
        $endTime = date('Y-m-d H:i:s', strtotime('+'.$meetingInfo['duration'].' minutes', strtotime($formattedDate)));
        return $endTime;
    }
}
