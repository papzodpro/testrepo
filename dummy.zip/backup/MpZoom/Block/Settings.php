<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoom
 * @author    Webkul Software Private Limited
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpZoom\Block;

class Settings extends \Magento\Framework\View\Element\Template
{
    public $helper;
    public $mpHelper;
    public $attrRepo;
    public $bookingInfo;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    public $storeManager;
    public $bookingHelper;
    public $infoCollection;
    public $configCollection;
    /**
     * __construct function
     *
     * @param \Webkul\MpZoom\Helper\Data $helper
     * @param \Webkul\Marketplace\Helper\Data $mpHelper
     * @param \Magento\Eav\Api\AttributeRepositoryInterface $attrRepo
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Webkul\MpAdvancedBookingSystem\Helper\Data $bookingHelper
     * @param \Webkul\MpZoom\Model\ResourceModel\MeetingInfo\CollectionFactory $infoCollection
     * @param \Webkul\MpZoom\Model\ResourceModel\ConfigData\CollectionFactory $configCollection
     * @param \Webkul\MpAdvancedBookingSystem\Model\ResourceModel\Info\CollectionFactory $bookingInfo
     * @param array $data
     */
    public function __construct(
        \Webkul\MpZoom\Helper\Data $helper,
        \Webkul\Marketplace\Helper\Data $mpHelper,
        \Magento\Eav\Api\AttributeRepositoryInterface $attrRepo,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\View\Element\Template\Context $context,
        \Webkul\MpAdvancedBookingSystem\Helper\Data $bookingHelper,
        \Webkul\MpZoom\Model\ResourceModel\MeetingInfo\CollectionFactory $infoCollection,
        \Webkul\MpZoom\Model\ResourceModel\ConfigData\CollectionFactory $configCollection,
        \Webkul\MpAdvancedBookingSystem\Model\ResourceModel\Info\CollectionFactory $bookingInfo,
        array $data = []
    ) {
        $this->helper = $helper;
        $this->mpHelper = $mpHelper;
        $this->attrRepo = $attrRepo;
        $this->bookingInfo = $bookingInfo;
        $this->storeManager = $storeManager;
        $this->bookingHelper = $bookingHelper;
        $this->infoCollection = $infoCollection;
        $this->configCollection = $configCollection;
        parent::__construct($context, $data);
    }
    
    /**
     * GetConfigData function
     *
     * @return object
     */
    public function getConfigData()
    {
        $sellerId = $this->mpHelper->getCustomerId();
        
        $collection = $this->configCollection->create()->addFieldToFilter('seller_id', $sellerId);
        
        return $collection->getFirstItem();
    }

    /**
     * GetMeetingData function
     *
     * @return \Webkul\MpZoom\Model\ResourceModel\MeetingInfo\Collection
     */
    public function getMeetingData()
    {
        $sellerId = $this->mpHelper->getCustomerId();
        
        $collection = $this->infoCollection->create()->addFieldToFilter('seller_id', $sellerId);
        $salesOrder = $collection->getTable('sales_order');
        $collection->getSelect()->joinLeft(
            ['so' => $salesOrder],
            "main_table.order_id = so.entity_id",
            [
                'increment_id' => 'so.increment_id'
            ]
        );
        return $collection;
    }

    /**
     * GetZoomAccountInfo function
     *
     * @return array
     */
    public function getZoomAccountInfo()
    {
        $sellerId = $this->mpHelper->getCustomerId();
        $zoomData = $this->helper->getZoomUserDetail($sellerId);
        $result = json_decode($zoomData, true);

        return $result;
    }

    /**
     * Get Customer Slots
     *
     * @return \Webkul\MpZoom\Model\ResourceModel\MeetingInfo\Collection
     */
    public function getCustomerMeetingData()
    {
        $customerId = $this->mpHelper->getCustomerId();
        
        $collection = $this->infoCollection->create();
        $salesOrder = $collection->getTable('sales_order');
        $collection->getSelect()->joinLeft(
            ['so' => $salesOrder],
            "main_table.order_id = so.entity_id AND so.customer_id = ".$customerId,
            [
                'increment_id' => 'so.increment_id'
            ]
        )->where('so.customer_id = '.$customerId);
        return $collection;
    }

    /**
     * Get Unbooked Customer Slots
     *
     * @param array $productIds
     * @return \Webkul\MpAdvancedBookingSystem\Model\ResourceModel\Info\Collection
     */
    public function getUnbookedSlot($productIds = null)
    {
        $appointmentAttrSetId = $this->bookingHelper->getProductAttributeSetIdByLabel(
            'Appointment Booking'
        );
        if (!$productIds) {
            $productIds = $this->mpHelper->getSellerProductData()->getColumnValues('mageproduct_id');
        }
        $bookingInfo = $this->bookingInfo->create()->addFieldToFilter("product_id", ['in' => $productIds])
            ->addFieldToFilter("attribute_set_id", ['in' => [$appointmentAttrSetId]]);

        $eavAttr = $bookingInfo->getTable('eav_attribute');
        $catelogEntity = $bookingInfo->getTable('catalog_product_entity_varchar');
        
        $bookingInfo->getSelect()->joinLeft(
            ['catalog_product_entity_varchar' => $catelogEntity],
            "main_table.product_id = catalog_product_entity_varchar.entity_id",
            ["slot_duration" => "value"]
        )->where(
            "catalog_product_entity_varchar.attribute_id = " . $this->getAttributeIdofProductSlotDuration()
        );
        return $bookingInfo;
    }

    /**
     * GetUnbookedCustomSlot
     *
     * @return \Webkul\MpAdvancedBookingSystem\Model\ResourceModel\Info\Collection
     */
    public function getUnbookedCustomSlot()
    {
        $customSlotAttrSetId = $this->bookingHelper->getProductAttributeSetIdByLabel(
            'Custom Slot Product'
        );
        $productIds = $this->mpHelper->getSellerProductData()->getColumnValues('mageproduct_id');
        $bookingInfo = $this->bookingInfo->create()->addFieldToFilter("product_id", ['in' => $productIds])
            ->addFieldToFilter("attribute_set_id", ['in' => [$customSlotAttrSetId]]);

        return $bookingInfo;
    }

    /**
     * Get Days Array
     *
     * @return array
     */
    public function getDayArray()
    {
        return $this->bookingHelper->dayLabelsFull;
    }

    /**
     * Get EAV id of the product name attribute
     *
     * @return mixed
     */
    private function getAttributeIdofProductSlotDuration()
    {
        $attr = $this->attrRepo;
        $productNameAttributeId = $attr->get('catalog_product', 'slot_duration')->getId();
        return $productNameAttributeId;
    }

    /**
     * Get Current Customer
     *
     * @return \Magento\Customer\Model\Customer
     */
    public function getCustomer()
    {
        return $this->mpHelper->getCustomer();
    }
}
