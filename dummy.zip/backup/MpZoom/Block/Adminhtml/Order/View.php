<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoom
 * @author    Webkul Software Private Limited
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpZoom\Block\Adminhtml\Order;

class View extends \Magento\Backend\Block\Widget\Form\Container
{
    /**
     * @var \Webkul\MpZoom\Helper\Data
     */
    public $helper;
    /**
     * Block group
     *
     * @var string
     */
    protected $_blockGroup = 'Magento_Sales';

    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * Sales config
     *
     * @var \Magento\Sales\Model\Config
     */
    protected $_salesConfig;

    /**
     * Reorder helper
     *
     * @var \Magento\Sales\Helper\Reorder
     */
    protected $_reorderHelper;

    /**
     * @param \Magento\Backend\Block\Widget\Context     $context
     * @param \Magento\Framework\Registry               $registry
     * @param \Magento\Sales\Model\Config               $salesConfig
     * @param \Magento\Sales\Helper\Reorder             $reorderHelper
     * @param \Webkul\MpZoom\Helper\Data           $helper
     * @param array                                     $data
     */
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Sales\Model\Config $salesConfig,
        \Magento\Sales\Helper\Reorder $reorderHelper,
        \Webkul\MpZoom\Helper\Data $helper,
        array $data = []
    ) {
        $this->_reorderHelper = $reorderHelper;
        $this->_coreRegistry = $registry;
        $this->_salesConfig = $salesConfig;
        $this->helper = $helper;
        parent::__construct($context, $data);
    }

    protected function _construct()
    {
        $this->_objectId = 'order_id';
        $this->_controller = 'adminhtml_order';
        $this->_mode = 'view';

        parent::_construct();
        $this->setId('sales_order_view');
        $order = $this->getOrder();

        if (!$order) {
            return;
        }
        $count = 0;
        foreach ($order->getAllItems() as $item) {
            if ($item->getProductType() == 'booking') {
                $count ++;
            }
        }
        if ($count && $order->hasInvoices() > 0) {
            $message = __('Send Email to customer with meeting details.');
            $this->addButton(
                'meeting_email',
                [
                    'label' => __('Send Meeting Email'),
                    'class' => 'meeting-email',
                    'id' => 'meeting-email-btn',
                    'onclick' => "confirmSetLocation('{$message}', '{$this->getEmailUrl()}')",
                    'data_attribute' => [
                        'url' => $this->getEmailUrl()
                    ]
                ]
            );
        }
    }

    /**
     * URL getter
     *
     * @param string $params
     * @param array $params2
     * @return string
     */
    public function getUrl($params = '', $params2 = [])
    {
        $params2['order_id'] = $this->getOrderId();
        return parent::getUrl($params, $params2);
    }

    /**
     * Retrieve order model object
     *
     * @return \Magento\Sales\Model\Order
     */
    public function getOrder()
    {
        return $this->_coreRegistry->registry('sales_order');
    }

    /**
     * Retrieve Order Identifier
     *
     * @return int
     */
    public function getOrderId()
    {
        return $this->getOrder() ? $this->getOrder()->getId() : null;
    }

    /**
     * Release URL getter
     *
     * @return string
     */
    public function getEmailUrl()
    {
        return $this->getUrl('mpzoom/*/meetingEmail');
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
}
