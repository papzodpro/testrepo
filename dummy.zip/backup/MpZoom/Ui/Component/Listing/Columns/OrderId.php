<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpZoom
 * @author    Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */

namespace Webkul\MpZoom\Ui\Component\Listing\Columns;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\UrlInterface;

class OrderId extends Column
{
    public $orderFactory;
    /**
     * @var \Magento\Framework\UrlInterface
     */
    public $urlBuilder;
    /**
     * @var ProductRepositoryInterface
     */
    public $productRepository;

    /**
     * construct
     *
     * @param \Magento\Framework\View\Element\UiComponent\ContextInterface $context
     * @param \Magento\Framework\View\Element\UiComponentFactory $uiComponentFactory
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $productRepository
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        ProductRepositoryInterface $productRepository,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        UrlInterface $urlBuilder,
        array $components = [],
        array $data = []
    ) {
        $this->productRepository = $productRepository;
        $this->orderFactory = $orderFactory;
        $this->urlBuilder = $urlBuilder;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source.
     *
     * @param array $dataSource
     *
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            $fieldName = $this->getData('order_id');
            
                // var_dump($fieldName);die;
            foreach ($dataSource['data']['items'] as &$item) {
                // print_r($item);die;
                if (isset($item['entity_id'])) {
                    $order = $this->orderFactory->create()->load($item['order_id']);
                    $item['order_id'] = "<a class='wk-option' 
                    href='".$this->urlBuilder->getUrl('marketplace/order/view', ['id' => $item['order_id']])."'>#".$order->getIncrementId().'</a>';
                }
            }
        }

        return $dataSource;
    }
}
